package com.telco.bnb.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class ReservationController {

	@GetMapping("/reservation")
	public String reservation(Model model,HttpServletRequest request) {
		System.out.println("잘 들어왔나");
		
		model.addAttribute("list", request.getParameter("list"));
		
		return "test";
	}
}
