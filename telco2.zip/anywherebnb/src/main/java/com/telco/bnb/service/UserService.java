package com.telco.bnb.service;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Service;

import com.telco.bnb.dto.UserDto;

public interface UserService {
	//회원가입
	public void register(UserDto dto) throws Exception;
	
	//로그인
	public UserDto getUser(UserDto dto) throws Exception;
	
	//로그아웃
	public void logout(HttpSession session);
}
