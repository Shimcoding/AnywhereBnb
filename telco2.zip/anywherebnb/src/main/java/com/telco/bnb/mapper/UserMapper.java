package com.telco.bnb.mapper;

import com.telco.bnb.dto.UserDto;

public interface UserMapper {
	
	//회원가입
	public void register(UserDto dto) throws Exception;
	
	//로그인
	public UserDto getUser(UserDto dto) throws Exception;
}
