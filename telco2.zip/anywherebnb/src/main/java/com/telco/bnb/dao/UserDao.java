package com.telco.bnb.dao;

import com.telco.bnb.dto.UserDto;

public interface UserDao {
	
	//회원가입
	public void register(UserDto dto) throws Exception;
	
	//로그인
	public UserDto getUser(UserDto dto) throws Exception;
}
