package com.telco.bnb.controller;

import java.net.URLEncoder;
import java.net.http.HttpRequest;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.telco.bnb.dto.UserDto;
import com.telco.bnb.service.UserServiceImple;

@Controller
@RequestMapping("/login")
public class LoginController {
	
	@Autowired
    private UserServiceImple userServiceImple;
	
	//로그인 입력 화면으로
	@GetMapping("/login")
    public String login(String t, Model model) {
        return "loginForm";
    }

    @GetMapping("/logout")
    public String logout(HttpSession session) {
        // 1. 세션을 종료
        session.invalidate();
        // 2. 홈으로 이동
        return "redirect:/index";
    }

    //로그인 성공,실패 여부
    @PostMapping("/login")
    public String loginCheck(HttpServletRequest request, UserDto dto, boolean rememberId,
    		RedirectAttributes rttr, HttpServletResponse response) {
    	
//    	System.out.println("login 메서드 진입");
//    	System.out.println("전달된 데이터: "+ dto);
    	
    	HttpSession session = request.getSession();
    	try {
			UserDto userDto = userServiceImple.getUser(dto);
			
			if(userDto == null) {
				
				int result = 0;
				rttr.addFlashAttribute("result", result);
				String msg = URLEncoder.encode("아이디 또는 비밀번호 틀렸습니다.","utf-8");
				
				return "redirect:/login/login?msg="+msg;
			}
			
			session.setAttribute("dto", userDto);
			System.out.println("rememberID: " + rememberId);
			//아이디 기억 버튼을 눌러 있으면
			if(rememberId) {
				//쿠키 생성
				Cookie cookie = new Cookie("id", userDto.getId());
				
				//응답에 저장
				response.addCookie(cookie);
			} else {
				//아이디 기억 버튼이 눌러 있지 않다면
				
				//쿠키 삭제
				Cookie cookie = new Cookie("id", userDto.getId());
				cookie.setMaxAge(0);
				
				//응답에 저장
				response.addCookie(cookie);
			}
			
			System.out.println(userDto.getId()+"로그인 성공");
			
			return "redirect:/index";
			
		} catch (Exception e) {
			
			e.printStackTrace();
		}
    	
    	
    	
    	return null;
    	
    }

}
