package com.telco.bnb.service;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Service;

import com.telco.bnb.dto.UserDto;

public interface UserService {
	//회원가입
	public void register(UserDto dto) throws Exception;
	
	//아이디 유효성 검사
	public int idChk(UserDto dto) throws Exception;
	
	//로그인
	public UserDto getUser(UserDto dto) throws Exception;
	
	//로그아웃
	public void logout(HttpSession session);
	
	//비밀번호 확인
	public UserDto getPwd(UserDto dto) throws Exception;
	
	//아이디 찾기
	public UserDto findId(UserDto dto) throws Exception;
	
	//비밀번호 찾기
	public UserDto findPwd(UserDto dto) throws Exception;
	
	//비밀번호 변경
	public void updatePw(String userId, String userPwd) throws Exception;
}
