package com.telco.bnb.controller;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Arrays;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.ibatis.reflection.SystemMetaObject;
import org.codehaus.jackson.map.ObjectMapper;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.input.SAXBuilder;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.sun.mail.imap.protocol.Item;
import com.telco.bnb.dto.AreaDto;
import com.telco.bnb.paging.Criteria;
import com.telco.bnb.service.AreaServiceImple;
import com.telco.bnb.service.UserServiceImple;

import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.io.BufferedReader;
import java.io.IOException;

@Controller
public class SearchController {
	
	
	@GetMapping("/search")
	public String search(HttpServletRequest request, Model model) throws IOException, Exception {
		HttpSession session = request.getSession();

		if (session.getAttribute("dto") == null) {
			return "redirect:/login/login";
		}

		
		try {
			int checkin = Integer.valueOf(request.getParameter("startDate").replaceAll("-", "")).intValue();
			int checkout = Integer.valueOf(request.getParameter("endDate").replaceAll("-", "")).intValue();
			
			if(checkin>=checkout) {
				String msg = URLEncoder.encode("체크인 날짜가 체크아웃 날짜보다 크거가 같을 수 업습니다.", "utf-8");
				
				return "redirect:/index?msg="+msg;
			}
		} catch (NullPointerException e) {
			System.out.println("처음에서 확인 완료");
		}
		//체크인 날짜가 체크아웃 날짜보다 크거나 같으면 다시 메인 화면으로
		
		
		
		System.out.println("lastpage="+request.getParameter("area_num"));
		System.out.println("pageStart="+request.getParameter("start"));
		System.out.println("pageEnd="+request.getParameter("end"));
		
		int lastPage = request.getParameter("area_num") == null ? 0 : Integer.valueOf(request.getParameter("area_num").trim());
		int pageStart = request.getParameter("start") == null ? 0 : Integer.valueOf(request.getParameter("start").trim());
		int pageEnd = request.getParameter("end") == null ? 5 : Integer.valueOf(request.getParameter("end").trim());
		
		StringBuffer sb;

		
		
		// 경상남도 검색
		if ("경남".equals(String.valueOf(request.getParameter("des")))
				|| String.valueOf(request.getParameter("des")).startsWith("경상")){

			jsonParsing(request, model, "Gyeongnam.json",pageStart,pageEnd);
			
		}

		// 경상북도 검색
		else if ("경북".equals(String.valueOf(request.getParameter("des")))
				|| String.valueOf(request.getParameter("des")).startsWith("경상북"))	{
			
			jsonParsing(request, model, "Gyeongbuk.json",pageStart,pageEnd);
			
		}
		
		// 충청북도 검색
		else if ("충북".equals(String.valueOf(request.getParameter("des")))
				|| String.valueOf(request.getParameter("des")).startsWith("충")
				|| String.valueOf(request.getParameter("des")).startsWith("충청북"))	{

			jsonParsing(request, model, "Chungbuk.json",pageStart,pageEnd);
			
		}
		
		// 경기도 검색
		else if ( String.valueOf(request.getParameter("des")).startsWith("경기"))	{

			jsonParsing(request, model, "Gyeonggi.json",pageStart,pageEnd);
			
			
			
		}
		
		// 서울 검색
		else if ( String.valueOf(request.getParameter("des")).startsWith("서울"))	{

			jsonParsing(request, model, "Seoul.json",pageStart,pageEnd);
			
			
			
		}
		
		// 제주 검색
		else if ( String.valueOf(request.getParameter("des")).startsWith("제"))	{

			jsonParsing(request, model, "Jeju.json",pageStart,pageEnd);
			
		}
		
		// 전라남도 검색
		else if ("전남".equals(String.valueOf(request.getParameter("des")))
				|| String.valueOf(request.getParameter("des")).startsWith("전")
				|| String.valueOf(request.getParameter("des")).startsWith("전라남"))	{

			jsonParsing(request, model, "Jeonnam.json",pageStart,pageEnd);
			
			
			
		}

		
		// 전라북도 검색
		else if ("전북".equals(String.valueOf(request.getParameter("des")))
				|| String.valueOf(request.getParameter("des")).startsWith("전라북"))	{

			jsonParsing(request, model, "Jeonbuk.json",pageStart,pageEnd);
			
			
		} 
		
		
		//검색 결과가 나오지 않았을 때
		else {
			
			jsonParsing(request, model, "Nothing.json",0,1);
			model.addAttribute("nothing","ok");
		}
		
		
		return "searchPage";

	}


	private void jsonParsing(HttpServletRequest request, Model model, String jsonName, int startNum, int endNum) throws Exception {
		JSONParser parser = new JSONParser();
		// JSON 파일 읽기
//		Reader reader = new FileReader("C:\\Users\\stt96\\Documents\\workspace-sts-3.9.17.RELEASE\\anywherebnb\\src\\main\\webapp\\resources\\json\\"+jsonName);
		Reader reader = new FileReader("C:\\Users\\user\\Documents\\workspace-sts-3.9.17.RELEASE\\anywherebnb\\src\\main\\webapp\\resources\\json\\"+jsonName);
		Object obj = parser.parse(reader);
		
		JSONObject jsonMain = (JSONObject)obj;
		
		JSONArray jsonArr = (JSONArray)jsonMain.get("result");
		
		AreaDto[] ar;
		
		if(jsonArr.size()>0) {
			
			ar = new AreaDto[jsonArr.size()];
			int j = 0;
			
			for (int i = 0; i < jsonArr.size(); i++) {
				
				JSONObject jsonObj = (JSONObject)jsonArr.get(i);
				
				
				String address = (String)jsonObj.get("adres"); 
				String category_name1 = (String)jsonObj.get("tourSe");
				String data_content = (String)jsonObj.get("intrcn");
				String category_name2 = (String)jsonObj.get("areaSe"); 
				String telno = (String)jsonObj.get("mobileTelno");
				String title = (String)jsonObj.get("tourNm");
				String roominfo = (String)jsonObj.get("roomInfo"); 
				String img = (String)jsonObj.get("thumbImg");
				
				
				AreaDto dto = new AreaDto(address, category_name1, data_content, category_name2, telno, title,
						roominfo, img);
				
				ar[j++] = dto;
				
				
				model.addAttribute("list", ar);
				model.addAttribute("start", startNum);
				model.addAttribute("end", endNum - 1);
				model.addAttribute("area_name", request.getParameter("des"));
				model.addAttribute("area_num", jsonArr.size());
			}
		}
		
	}

	
	
}