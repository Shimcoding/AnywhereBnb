package com.telco.bnb.service;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.apache.commons.mail.HtmlEmail;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.telco.bnb.dao.AreaDao;
import com.telco.bnb.dao.UserDao;
import com.telco.bnb.dto.AreaDto;
import com.telco.bnb.dto.UserDto;
import com.telco.bnb.mapper.UserMapper;
import com.telco.bnb.paging.Criteria;

@Service
public class AreaServiceImple implements AreaService{

	public AreaServiceImple() {
	}
	
	@Autowired
	private AreaDao dao;
	


	@Override
	public void area_register(AreaDto dto) throws Exception {
		System.out.println("DB area에 정보 넣기 시작");
		
		dao.area_register(dto);
		
	}



	@Override
	public void area_delete() throws Exception {
		System.out.println("DB area에 정보 삭제 시작");

		dao.area_delete();
	}



	@Override
	public int area_select(AreaDto dto) throws Exception {
		System.out.println("DB area에 정보 검색 시작");
		
		return dao.area_select(dto);
	}



	@Override
	public void area_seq() throws Exception {
		System.out.println("시퀀스 생성 시작");
		
		dao.area_seq();
		
	}



	@Override
	public void seq_drop() throws Exception {
		System.out.println("시퀀스 삭제 시작");
		
		dao.seq_drop();
	}



	@Override
	public List<AreaDto> listCriteria(Criteria criteria) throws Exception {

		return dao.listCriteria(criteria);
	}



	
}
