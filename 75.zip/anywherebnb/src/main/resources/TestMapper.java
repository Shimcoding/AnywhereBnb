import org.springframework.stereotype.Repository;

@Repository
public interface TestMapper {
	String selectnow();
}
