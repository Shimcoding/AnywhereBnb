package com.telco.bnb.dao;

import java.util.HashMap;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.telco.bnb.dto.AreaDto;
import com.telco.bnb.dto.UserDto;
import com.telco.bnb.mapper.UserMapper;

@Repository
public class UserDaoImpl implements UserDao{

	public UserDaoImpl() {
		
	}
	
	@Autowired(required = false) //Inject 쓰지 말고 Autowired으로 고치기
	private SqlSession sqlSession;

	
	//회원가입
	@Override
	public void register(UserDto dto) throws Exception {
//		System.out.println("userDao: "+ dto);
		System.out.println("회원가입 DB 접근 시작");
//		sqlSession.insert(namespace+".register", dto);
		
		try {
			sqlSession.insert("com.telco.bnb.mapper.UserMapper.register", dto);
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("이유: " + e.getMessage());
			System.out.println("이유: " + e.getLocalizedMessage());
		}
		
		System.out.println("회원가입 DB 접근 종료");
	}


	//로그인
	@Override
	public UserDto getUser(UserDto dto) {
		
		System.out.println("로그인 DB 접근 시작");
		
		UserDto res = null;
		try {
			res = sqlSession.selectOne("com.telco.bnb.mapper.UserMapper.getUser",dto);
		} catch (Exception e) {
			System.out.println("로그인 실패");
			e.printStackTrace();
		}
		return res;
	}


	//비밀번호 확인
	@Override
	public UserDto getPwd(UserDto dto) throws Exception {
		System.out.println("비밀번호 확인 DB 접근 시작");
		
		return sqlSession.selectOne("com.telco.bnb.mapper.UserMapper.getPwd", dto.getPwd());
	}


	//아이디 찾기
	@Override
	public UserDto findId(UserDto dto) throws Exception {
		
		return sqlSession.selectOne("com.telco.bnb.mapper.UserMapper.findId", dto);
	}


	//비밀번호 찾기
	@Override
	public UserDto findPwd(UserDto dto) throws Exception {

		return sqlSession.selectOne("com.telco.bnb.mapper.UserMapper.findPwd", dto);
	}


	//비밀번호 변경
	@Override
	public void updatePw(String userId, String userPwd) throws Exception {
		
		Map<String, String> map = new HashMap<>();
		map.put("id", userId);
		map.put("pwd", userPwd);
		
		sqlSession.update("com.telco.bnb.mapper.UserMapper.updatePw", map);
	}


	//아이디 중복 검사
	@Override
	public int idChk(UserDto dto) throws Exception {
		
		return sqlSession.selectOne("com.telco.bnb.mapper.UserMapper.idChk",dto);
	}


	//암호화된 비밀번호 가져오기
	@Override
	public UserDto getIdPwd(UserDto dto) throws Exception {

		return sqlSession.selectOne("com.telco.bnb.mapper.UserMapper.getIdPwd",dto.getId());
	}


	//이메일 중복 검사
	@Override
	public int emailChk(UserDto dto) throws Exception {
		
		return sqlSession.selectOne("com.telco.bnb.mapper.UserMapper.emailChk",dto);
	}


	//연락처 중복 검사
	@Override
	public int telChk(UserDto dto) throws Exception {

		return sqlSession.selectOne("com.telco.bnb.mapper.UserMapper.telChk",dto);
	}


	//마이페이지 정보 가져오기
	public UserDto mypage(UserDto dto) throws Exception{
		
		return sqlSession.selectOne("com.telco.bnb.mapper.UserMapper.mypage", dto);
		
	}

	//마이페이지 회원 탈퇴
	@Override
	public void mypageDelete(UserDto dto) throws Exception {
		
		sqlSession.delete("com.telco.bnb.mapper.UserMapper.mypageDelete",dto);
	}

	//마이페이지 회원 정보 수정
	@Override
	public void mypageUpdate(UserDto dto) throws Exception {
		
		sqlSession.update("com.telco.bnb.mapper.UserMapper.mypageUpdate",dto);
	}


	@Override
	public void area_register(AreaDto dto) throws Exception {

		sqlSession.insert("com.telco.bnb.mapper.AreaMapper.area_register",dto);
	}





}
