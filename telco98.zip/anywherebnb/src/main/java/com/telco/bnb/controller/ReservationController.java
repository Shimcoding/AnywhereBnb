package com.telco.bnb.controller;

import java.net.URLEncoder;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.telco.bnb.dto.ManageDto;
import com.telco.bnb.dto.PayDto;
import com.telco.bnb.dto.UserDto;
import com.telco.bnb.service.ManageService;
import com.telco.bnb.service.UserServiceImple;




@Controller
public class ReservationController {

	@Autowired
	private ManageService manageService;
	
	@Autowired
    private UserServiceImple userServiceImple;
	
	
	//비밀번호 암호화
	@Autowired(required = false)
	BCryptPasswordEncoder pwdEncoder;
	
	@GetMapping("/reservation")
	public String reservation_out(Model model,HttpServletRequest request) {
		System.out.println("잘 들어왔나");

		
		System.out.println("item_title:"+request.getParameter("item_title"));
		System.out.println("item_price:"+request.getParameter("item_price"));
		System.out.println("buyer_email:"+request.getParameter("buyer_email"));
		System.out.println("buyer_name:"+request.getParameter("buyer_name"));
		System.out.println("buyer_tel:"+request.getParameter("buyer_tel"));
		
		return "test";
	}
	
	@PostMapping("/reservation")
	public String reservation_in(Model model,PayDto payDto,HttpServletRequest request) throws Exception {
		
		HttpSession session = request.getSession();
		
		if(session.getAttribute("dto")==null) {
			String msg = URLEncoder.encode("잘못된 접근입니다.","utf-8");
			
			return "redirect:/index?msg="+msg;
		}
		
		System.out.println(request.getParameter("item_title"));
		System.out.println(request.getParameter("address"));
		
		System.out.println(payDto);
		
		model.addAttribute("payDto",payDto);
		model.addAttribute("item_title",request.getParameter("item_title"));
		model.addAttribute("item_price",request.getParameter("item_price"));
		model.addAttribute("address",request.getParameter("address"));
		model.addAttribute("su",request.getParameter("su"));
		model.addAttribute("num",request.getParameter("num"));
		model.addAttribute("startDate_ymd",request.getParameter("startDate_ymd"));
		model.addAttribute("endDate_ymd",request.getParameter("endDate_ymd"));
		model.addAttribute("buyer_email",request.getParameter("buyer_email"));
		model.addAttribute("buyer_name",request.getParameter("buyer_name"));
		model.addAttribute("buyer_tel",request.getParameter("buyer_tel"));
		
		
		return "payForm";
	}
	
	//예약 관리로 들어가기 전 비밀번호 확인
	@GetMapping("/managebefore")
	public String managebefore(HttpServletRequest request) throws Exception {

		HttpSession session = request.getSession();
		
		if(session.getAttribute("dto")==null) {
			String msg = URLEncoder.encode("잘못된 접근입니다.","utf-8");
			
			return "redirect:/index?msg="+msg;
		}
		
		return "manageFormbefore";
	}
	
	//해당 사용자의 예약 정보 가져오기
	@PostMapping("/manageOk")
	public String mypageBefore2(HttpServletRequest request, Model model) throws Exception {
		HttpSession session = request.getSession();
		
		if(session.getAttribute("dto")==null) {
			
			String msg = URLEncoder.encode("잘못된 접근입니다.","utf-8");
			
			
			return "redirect:/index?msg="+msg;
		}
		
		UserDto dto = (UserDto)session.getAttribute("dto");
		boolean isMatches = pwdEncoder.matches(request.getParameter("pwd"), dto.getPwd());
		
		if(isMatches) {
			
			UserDto myDto = userServiceImple.mypage(dto);
			myDto.setPwd(request.getParameter("pwd"));
			model.addAttribute("myDto", myDto);


			UserDto uDto = userServiceImple.mypage(dto);
			
			ManageDto resDto = new ManageDto();
			resDto.setBuyer_name(uDto.getName());
			resDto.setBuyer_email(uDto.getEmail());
			resDto.setBuyer_tel(uDto.getTel());
			
			List<ManageDto> list = manageService.findRes(resDto);
			
			
			model.addAttribute("list",list);
			model.addAttribute("size", list.size() == 0 ? 0 : list.size());
			
			
			
			
			return "manageForm";
			
		} else {
			
			String msg = URLEncoder.encode("비밀번호를 다시 입력해주세요.","utf-8");
			return "redirect:/mypagebefore?msg="+msg;
		
		}
		
	}
	
	//예약 관리 정보 넣기
	@PostMapping("/manage")	
	public @ResponseBody String manage(@RequestParam Map<String, Object> map) throws Exception {
		System.out.println("map:"+map);
		System.out.println("예약 정보에 넣기");
		manageService.manage(map);
		
		return "index";
	}
	
	@PostMapping("/manageDelete")
	@ResponseBody
	public void manageDelete(HttpServletRequest request) throws Exception {
		String[] valueArr = request.getParameterValues("valueArr");
		
		System.out.println("valueArr:"+ Arrays.toString(valueArr));
		for (int i = 0; i < valueArr.length; i++) {
			ManageDto mdto = new ManageDto();
			mdto.setTitle(valueArr[i].substring(0,valueArr[i].indexOf(",")));
			mdto.setDate(valueArr[i].substring(valueArr[i].indexOf(",")+1));
			System.out.println(valueArr[i].substring(0,valueArr[i].indexOf(",")));
			System.out.println(valueArr[i].substring(valueArr[i].indexOf(",")+1));
			manageService.deleteRes(mdto);
		}
		
	}
	
	
	
}
