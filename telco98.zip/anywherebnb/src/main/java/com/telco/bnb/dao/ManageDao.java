package com.telco.bnb.dao;

import java.util.List;
import java.util.Map;

import com.telco.bnb.dto.ManageDto;
import com.telco.bnb.dto.PayDto;
import com.telco.bnb.dto.UserDto;


public interface ManageDao {
	
	//예약 정보 삽입
	public void manage(Map<String, Object>  map) throws Exception;
	
	//현재 사용자의 예약 관리 정보 가져오기
	public List<ManageDto> findRes(ManageDto dto) throws Exception;
	
	//현재 사용자의 선택된 예약 정보 삭제
	public void deleteRes(ManageDto dto) throws Exception;
	
	//회원탈퇴 시 예약 관리에 정보가 있는지 확인
	public int findName(String id) throws Exception;
}
