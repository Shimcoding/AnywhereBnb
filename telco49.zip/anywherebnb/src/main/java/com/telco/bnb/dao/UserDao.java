package com.telco.bnb.dao;

import com.telco.bnb.dto.UserDto;

public interface UserDao {
	
	//회원가입
	public void register(UserDto dto) throws Exception;
	
	//아이디 중복 검사
	public int idChk(UserDto dto) throws Exception;
	
	//로그인
	public UserDto getUser(UserDto dto) throws Exception;
	
	//암호화된 비밀번호 가져오기
	public UserDto getIdPwd(UserDto dto) throws Exception;
	
	//비밀번호 확인
	public UserDto getPwd(UserDto dto) throws Exception;
	
	//아이디 찾기
	public UserDto findId(UserDto dto) throws Exception;
	
	//비밀번호 찾기
	public UserDto findPwd(UserDto dto) throws Exception;
	
	//비밀번호 변경
	public void updatePw(String userId, String userPwd) throws Exception;
	
	//이메일 중복 검사
	public int emailChk(UserDto dto) throws Exception;
	
	//연락처 중복 검사
	public int telChk(UserDto dto) throws Exception;
	
	//마이페이지 사용자 정보 가져오기
	public UserDto mypage(UserDto dto) throws Exception;
	
	//마이페이지 회원 탈퇴
	public void mypageDelete(UserDto dto) throws Exception;
	
	//마이페이지 회원 정보 수정
	public void mypageUpdate(UserDto dto) throws Exception;
}
