package com.telco.bnb.controller;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.net.http.HttpRequest;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.test.context.web.AbstractGenericWebContextLoader;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.telco.bnb.dto.UserDto;
import com.telco.bnb.service.UserServiceImple;

@Controller
@RequestMapping("/login")
public class LoginController {
	
	@Autowired
    private UserServiceImple userServiceImple;
	
	@Autowired
	private BCryptPasswordEncoder passwordEncoder;
	
	//로그인 입력 화면으로
	@GetMapping("/login")
    public String login(Model model, HttpSession session) throws Exception {
		//로그인 상태에서 로그인 화면으로 가면 초기 화면으로 이동
		if(session.getAttribute("dto")!=null) {
			String msg = URLEncoder.encode("잘못된 접근입니다.","utf-8");
			
			return "redirect:/index?msg="+msg;
		}
		
        return "loginForm";
    }

    @GetMapping("/logout")
    public String logout(HttpSession session) {
        // 1. 세션을 종료
        session.removeAttribute("dto");
//        session.invalidate();  
        // 2. 홈으로 이동
        return "redirect:/index";
    }

    //로그인 성공,실패 여부
    @PostMapping("/login")
    public String loginCheck(HttpServletRequest request, UserDto dto, boolean rememberId,
    		RedirectAttributes rttr, HttpServletResponse response, String id, String pwd) throws Exception{
    	
    	System.out.println(id);
    	System.out.println(pwd);
    	
    	//사용자가 입력한 비밀번호와 암호화된 비밀번호와 비교
    	//복호화해서 같으면 1반환, 다르면 0반환 
    	UserDto encode = userServiceImple.getIdPwd(dto);
    	HttpSession session = request.getSession();
    	
    	//아이디가 잘못돼 로그인을 실패할 경우
    	if(encode == null) {
    		session.setAttribute("dto", null);
			
			//아이디 또는 비밀번호가 틀린 걸 알려준다
			String msg = URLEncoder.encode("아이디 또는 비밀번호가 틀렸습니다.","utf-8");
			
			return "redirect:/login/login?msg="+msg;
    	}
    	
    	boolean isMatches = passwordEncoder.matches(pwd, encode.getPwd());
    	
		dto.setPwd(encode.getPwd());
		UserDto userDto = userServiceImple.getUser(dto);
		
		
		
//		//아이디는 맞았는데 
//		if(userDto == null) {
//			
//			session.setAttribute("dto", null);
//			
//			//아이디 또는 비밀번호가 틀린 걸 알려준다
//			String msg = URLEncoder.encode("아이디 또는 비밀번호가 틀렸습니다.","utf-8");
//			
//			return "redirect:/login/login?msg="+msg;
//		}
		
		
		//아이디는 맞았는데 비밀번호가 틀린 경우
		if(!isMatches) {
		
			session.setAttribute("dto", null);
			rttr.addFlashAttribute("msg", false);
			
			//아이디 또는 비밀번호가 틀린 걸 알려준다
			String msg = URLEncoder.encode("아이디 또는 비밀번호가 틀렸습니다.","utf-8");
			
			return "redirect:/login/login?msg="+msg;
		} else {
			
			//아이디와 비밀번호 모두 맞아서 로그인이 된 경우
			
			session.setAttribute("dto", userDto);
			
			
			
			//아이디 기억 버튼이 눌러 있으면
			if(rememberId) {
				
				//쿠키 생성
				Cookie cookie = new Cookie("id", userDto.getId());
				cookie.setMaxAge(60);
				
				//응답에 저장
				response.addCookie(cookie);
			} else {
				
				//아이디 기억 버튼이 눌러 있지 않다면
				
				//쿠키 삭제
				Cookie cookie = new Cookie("id", userDto.getId());
				cookie.setMaxAge(0);
				
				//응답에 저장
				response.addCookie(cookie);
			}
			
			System.out.println("로그인 성공");
			
			return "redirect:/index";
			
			
			
		}
		
			
    	
    }

}
