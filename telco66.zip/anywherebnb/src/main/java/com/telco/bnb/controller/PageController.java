package com.telco.bnb.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class PageController {

	@GetMapping("/prepaging")
	public String paging1(Model model,HttpServletRequest request) {
		
		System.out.println(request.getParameter("start"));
		System.out.println(request.getParameter("end"));
		
		int preStart = Integer.valueOf(request.getParameter("start"))-5;
		int preEnd = Integer.valueOf(request.getParameter("end"))-5;
		
		model.addAttribute("start", String.valueOf(preStart));
		model.addAttribute("end", String.valueOf(preEnd));
		
		return "test";
	}
	
	@GetMapping("/nextpaging")
	public String paging2(Model model,HttpServletRequest request) {
		
		System.out.println(request.getParameter("start"));
		System.out.println(request.getParameter("end"));
		
		int nextStart = Integer.valueOf(request.getParameter("start"))+5;
		int nextEnd = Integer.valueOf(request.getParameter("end"))+5;
		
		System.out.println("nextStart:"+ nextStart);
		System.out.println("nextEnd:"+ nextEnd);
		
		model.addAttribute("start", String.valueOf(nextStart));
		model.addAttribute("end", String.valueOf(nextEnd));
		
		return "test";
	}
}
