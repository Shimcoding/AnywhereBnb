package com.telco.bnb.service;

import javax.servlet.http.HttpSession;

import org.apache.commons.mail.HtmlEmail;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.telco.bnb.dao.UserDao;
import com.telco.bnb.dto.AreaDto;
import com.telco.bnb.dto.UserDto;
import com.telco.bnb.mapper.UserMapper;

@Service
public class UserServiceImple implements UserService{

	public UserServiceImple() {
	}
	
	@Autowired
	private UserDao dao;
	
	@Autowired
	private UserMapper userMapper;
	
	//회원가입
	@Override
	public void register(UserDto dto) throws Exception {
		System.out.println("회원가입 서비스 시작");
//		System.out.println("service:"+dto);
		dao.register(dto);
//		userMapper.register(dto);
		System.out.println("회원가입 서비스 끝");
		
	}

	//로그인
	@Override
	public UserDto getUser(UserDto dto) throws Exception {
		System.out.println("ServiceImpl 로그인 시작");
		
		System.out.println("ServiceImpl:"+dto);
		return dao.getUser(dto);
	}

	//로그아웃
	@Override
	public void logout(HttpSession session) {
		System.out.println("로그아웃 시작");
		
		session.invalidate();
		
	}

	//비밀번호 확인
	@Override
	public UserDto getPwd(UserDto dto) throws Exception {
		System.out.println("비밀번호 확인 시작");
		
		return dao.getPwd(dto);
	}

	@Override
	public UserDto findId(UserDto dto) throws Exception {
		System.out.println("아이디 찾기 시작");
		
		return dao.findId(dto);
	}

	@Override
	public UserDto findPwd(UserDto dto) throws Exception {
		System.out.println("비밀번호 찾기 시작");
		
		return dao.findPwd(dto);
	}

	@Override
	public void updatePw(String userId, String userPwd) throws Exception {
		System.out.println("비밀번호 변경 시작");
		dao.updatePw(userId, userPwd);
	}

	@Override
	public int idChk(UserDto dto) throws Exception {
		return dao.idChk(dto);
	}

	@Override
	public UserDto getIdPwd(UserDto dto) throws Exception {
		System.out.println("암호화된 비밀번호 가져오기 시작");
		
		return dao.getIdPwd(dto);
	}

	@Override
	public int emailChk(UserDto dto) throws Exception {
		
		return dao.emailChk(dto);
	}

	@Override
	public int telChk(UserDto dto) throws Exception {
		
		return dao.telChk(dto);
	}

	@Override
	public UserDto mypage(UserDto dto) throws Exception {
		System.out.println("개인정보 관리에 정보 가져오기 시작");

		return dao.mypage(dto);
	}

	@Override
	public void mypageDelete(UserDto dto) throws Exception {
		System.out.println("탈퇴 시작");
		
		dao.mypageDelete(dto);
	}

	@Override
	public void mypageUpdate(UserDto dto) throws Exception {
		System.out.println("개인정보 관리 회원 정보 변경 시작");
		
		dao.mypageUpdate(dto);
		
	}

	@Override
	public void area_register(AreaDto dto) throws Exception {
		
		dao.area_register(dto);
		
	}

	@Override
	public UserDto pay(UserDto dto) throws Exception {

		return dao.pay(dto);
	}

//	@Override
//	public int loginCheck(String userId) throws Exception {
//		System.out.println("로그인 중복 확인 시작");
//		
//		return dao.loginCheck(userId);
//	}
//
//	@Override
//	public void updateCheck(String userId) throws Exception {
//		System.out.println("로그인 성공 후 로그인체크 1로 변경");
//		
//		dao.updateCheck(userId);
//
//	}
//
//	@Override
//	public void updateCheck2(String userId) throws Exception {
//		System.out.println("로그아웃 후 로그인체크 0으로 변경");
//		
//		dao.updateCheck2(userId);
//	}

	
}
