package com.telco.bnb.controller;

import java.io.IOException;
import java.net.URLEncoder;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.telco.bnb.dto.JejuDto;
import com.telco.bnb.dto.PayDto;
import com.telco.bnb.dto.UserDto;
import com.telco.bnb.service.JejuServiceImpl;
import com.telco.bnb.service.UserServiceImple;


@Controller
public class SearchController {

	@Autowired
	private JejuServiceImpl jejuServiceImpl;
	
	@Autowired
	private UserServiceImple userServiceImple;
	
	@GetMapping("/search")
	public String search(HttpServletRequest request, Model model, JejuDto jdto) throws IOException, Exception {
		HttpSession session = request.getSession();

		//현재 날짜 월-일
		int s_cur = Integer.valueOf(request.getParameter("startCur").replace("-", ""));
		//현재 날짜 년도
		int startYear = Integer.valueOf(request.getParameter("startYear")) + 1;
		//체크인할 날짜 월-일
		int s_date = Integer.valueOf(request.getParameter("startDate").replace("-", ""));
		//체크아웃할 날짜 월-일
		int e_date = Integer.valueOf(request.getParameter("endDate").replace("-", ""));
		
		System.out.println("startYear:"+startYear);
		
		if (session.getAttribute("dto") == null) {
			return "redirect:/login/login";
		}

		
		Date format1 = new SimpleDateFormat("yyyy-MM-dd").parse(s_cur <= s_date ? (request.getParameter("startYear")+"-"+request.getParameter("startDate")) : String.valueOf(startYear)+"-"+request.getParameter("startDate"));
		Date format2 = new SimpleDateFormat("yyyy-MM-dd").parse(s_cur <= e_date ? (request.getParameter("startYear")+"-"+request.getParameter("endDate")) : String.valueOf(startYear)+"-"+request.getParameter("endDate"));

		long diff = ((format2.getTime() - format1.getTime()) / 1000) / (24*60*60);
		
		
		if (diff < 0) {
			String msg = URLEncoder.encode("체크인 날짜가 체크아웃 날짜보다 크거가 같을 수 업습니다.", "utf-8");

			return "redirect:/index?msg=" + msg;
		}
		// 체크인 날짜가 체크아웃 날짜보다 크거나 같으면 다시 메인 화면으로

		int start = request.getParameter("start") == null ? 0 : Integer.valueOf(request.getParameter("start"));
		int end = request.getParameter("end") == null ? 19 : Integer.valueOf(request.getParameter("end"));
		
		jdto.setAddress(request.getParameter("des"));
		jdto.setTitle(request.getParameter("des"));
		System.out.println("jdto:"+jdto);
		
		// 검색 결과 개수
		int cnt = jejuServiceImpl.sukCountSearch(jdto);
		// 검색된 데이터의 이름,주소,전화번호(전화번호는 없을 수 있음)
		List<JejuDto> list = jejuServiceImpl.sukSearch(jdto);
		
		
		//현재 날짜 구하기
		LocalDate now = LocalDate.now();
		
		
		//현재 날짜 이전과 현재 날짜로부터 1년이 넘는 날짜들은 선택 불가
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

		String start11 = formatter.format(now);
		String last11 = formatter.format(now.plusYears(1));
		
		model.addAttribute("start11",start11); //현재 날짜
		model.addAttribute("last11",last11); //현재로부터 1년 뒤 날짜
		
		
		
		model.addAttribute("cnt",cnt); //검색을 통해 나온 객체들의 총 수
		model.addAttribute("list",list); //검색을 통해 나온 객체들
		model.addAttribute("des",request.getParameter("des")); //검색어
		model.addAttribute("start",start); //페이징
		model.addAttribute("end",end); //페이징 
		model.addAttribute("su",request.getParameter("su")); //인원 수
		
		
		//체크인 날짜와 체크아웃 날짜 사이의 간격 계산 -> 몇 박 동안 숙박하는지
		
		
		
		//현재 날짜 월-일보다 같거나 크면 현재 날짜의 년도랑 같음
		//현재 날짜 월-일보다 작으면 현재 날짜의 다음 년도랑 같음
		
		System.out.println(format1);
		System.out.println(format2);
		
		
		model.addAttribute("startCur", request.getParameter("startCur"));
		model.addAttribute("startYear", request.getParameter("startYear"));
		model.addAttribute("startDate",request.getParameter("startDate"));
		model.addAttribute("endDate",request.getParameter("endDate"));
		
		System.out.println(request.getParameter("su"));
		
		//임의로 책정한 가격
		int arr = (int)((Math.random()*9)+1)*10000;
		int arr_price = 0;
		try {
			arr_price = arr*(int)diff * Integer.valueOf(request.getParameter("su"));
			
		} catch (Exception e) {
			arr_price = 3000;
		}
		
		model.addAttribute("arr",arr); //임의로 책정한 가격
		model.addAttribute("arr_price",arr_price); //임의로 책정한 가격
		
		
		//결제 구매자 정보를 위해서 
		UserDto userDto = userServiceImple.pay((UserDto)session.getAttribute("dto"));
		PayDto payDto = new PayDto(userDto.getEmail(),userDto.getName(),userDto.getTel());
		model.addAttribute("payDto",payDto);
		
		
		return "searchPage";

	}

}