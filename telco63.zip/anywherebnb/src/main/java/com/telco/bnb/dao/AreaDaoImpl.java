package com.telco.bnb.dao;

import java.util.HashMap;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.telco.bnb.dto.AreaDto;
import com.telco.bnb.dto.UserDto;
import com.telco.bnb.mapper.UserMapper;

@Repository
public class AreaDaoImpl implements AreaDao{

	public AreaDaoImpl() {
		
	}
	
	@Autowired(required = false) //Inject 쓰지 말고 Autowired으로 고치기
	private SqlSession sqlSession;

	

	//DB area에 지역 정보 넣기
	@Override
	public void area_register(AreaDto dto) throws Exception {

		sqlSession.insert("com.telco.bnb.mapper.AreaMapper.area_register",dto);
	}



	//DB area에 지역 정보 검색
	@Override
	public int area_select(AreaDto dto) throws Exception {

		return sqlSession.selectOne("com.telco.bnb.mapper.AreaMapper.area_select",dto);
	}



	@Override
	public void area_delete(){
		
		sqlSession.delete("com.telco.bnb.mapper.AreaMapper.area_delete");
		
	}







}
