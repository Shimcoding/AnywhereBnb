package com.telco.bnb.dto;

public class AreaDto {
	private int num; //번호
	private String address;  //숙박 주소
	private String category_name1; //ex.펜션,호텔
	private String data_content;  //숙박 소개(없는 것도 있음)
	private String category_name2; //ex.서울시, 거제시
	private String telno;  //숙박 연락처
	private String title;  //숙박 이름
	private String roominfo; //객실 수
	private String img; //보여줄 사진
	
	
	public AreaDto() {
		
	}
	

	public AreaDto(String address, String category_name1, String data_content, String category_name2, String telno,
			String title, String roominfo, String img) {
		super();
		this.address = address;
		this.category_name1 = category_name1;
		this.data_content = data_content;
		this.category_name2 = category_name2;
		this.telno = telno;
		this.title = title;
		this.roominfo = roominfo;
		this.img = img;
	}
	
	public AreaDto(String address, String category_name1, String data_content, String category_name2, String telno,
			String title, String roominfo) {
		super();
		this.address = address;
		this.category_name1 = category_name1;
		this.data_content = data_content;
		this.category_name2 = category_name2;
		this.telno = telno;
		this.title = title;
		this.roominfo = roominfo;
	}


	public int getNum() {
		return num;
	}


	public void setNum(int num) {
		this.num = num;
	}


	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCategory_name1() {
		return category_name1;
	}

	public void setCategory_name1(String category_name1) {
		this.category_name1 = category_name1;
	}

	public String getData_content() {
		return data_content;
	}

	public void setData_content(String data_content) {
		this.data_content = data_content;
	}

	public String getCategory_name2() {
		return category_name2;
	}

	public void setCategory_name2(String category_name2) {
		this.category_name2 = category_name2;
	}

	public String getTelno() {
		return telno;
	}

	public void setTelno(String telno) {
		this.telno = telno;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	
	public String getRoominfo() {
		return roominfo;
	}


	public void setRoominfo(String roominfo) {
		this.roominfo = roominfo;
	}


	public String getImg() {
		return img;
	}


	public void setImg(String img) {
		this.img = img;
	}


	@Override
	public String toString() {
		return "AreaDto [num=" + num + ", address=" + address + ", category_name1=" + category_name1 + ", data_content="
				+ data_content + ", category_name2=" + category_name2 + ", telno=" + telno + ", title=" + title
				+ ", roominfo=" + roominfo + ", img=" + img + "]";
	}

	
	
}
