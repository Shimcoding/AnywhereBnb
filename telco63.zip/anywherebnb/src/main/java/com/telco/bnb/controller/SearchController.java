package com.telco.bnb.controller;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.input.SAXBuilder;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.sun.mail.imap.protocol.Item;
import com.telco.bnb.dto.AreaDto;
import com.telco.bnb.service.AreaServiceImple;
import com.telco.bnb.service.UserServiceImple;

import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.io.BufferedReader;
import java.io.IOException;

@Controller
public class SearchController {

	@Autowired(required = false)
	private AreaServiceImple areaServiceImple;
	
	
	//
	@GetMapping("/search")
	public String search(HttpServletRequest request, Model model) throws IOException, Exception {
		HttpSession session = request.getSession();

		if (session.getAttribute("dto") == null) {
			return "redirect:/login/login";
		}

		final int startNum = 0;
		final int endNum = 30;

		int pageNum = 1;
		int lastPage = 0; 
		
		StringBuffer sb;

		//DB에 정보 모두 삭제
		areaServiceImple.area_delete();
		
		
		// 경상남도 검색
		if ("경남".equals(String.valueOf(request.getParameter("des")))
				|| String.valueOf(request.getParameter("des")).startsWith("경상")) {

			for (int j = pageNum; j <= endNum; j++) {

				sb = new StringBuffer("http://apis.data.go.kr/6480000/gyeongnamlodgeinfo/gyeongnamlodgeinfolist?");

				sb.append(
						"ServiceKey=LymnrNWuKh%2Fy7EZcYycf4cfSzKDriE38ICY5nsnLuPZbphsaOHGDaWAO%2F%2B45yD1EkQkH79tD6C%2FLjMCHXAfk0A%3D%3D");
				sb.append("&pageNo=" + j);
				sb.append("&numOfRows=" + endNum);

				List<Element> item_list = urlList(sb.toString());

				AreaDto[] ar = new AreaDto[item_list.size()];

				lastPage += item_list.size();
				
				if(j==endNum)
					System.out.println("총 페이지: "+lastPage);
				
				int i = 0;
				for (Element item : item_list) {
					
					String address = item.getChildText("user_address");
					String category_name1 = item.getChildText("category_name1");
					String data_content = item.getChildText("data_content");
					String category_name2 = item.getChildText("category_name3");
					String telno = item.getChildText("telno");
					String title = item.getChildText("data_title");
					String roominfo = item.getChildText("roominfo");
					String img = item.getChildText("fileurl1");

					AreaDto dto = new AreaDto(address, category_name1, data_content, category_name2, telno, title,
							roominfo, img);
					
					areaServiceImple.area_register(dto);

					ar[i++] = dto;
					
					model.addAttribute("list", ar);
					model.addAttribute("start", startNum);
					model.addAttribute("end", endNum - 1);
				}
			}

			
		}

		// 충청북도 검색
		else if ("충북".equals(String.valueOf(request.getParameter("des")))
				|| String.valueOf(request.getParameter("des")).startsWith("충청북")) {

			sb = new StringBuffer(
					"https://tour.chungbuk.go.kr/openapi/tourInfo/stay.do?");

			sb.append(
					"ServiceKey=LymnrNWuKh%2Fy7EZcYycf4cfSzKDriE38ICY5nsnLuPZbphsaOHGDaWAO%2F%2B45yD1EkQkH79tD6C%2FLjMCHXAfk0A%3D%3D");
			
			
			List<Element> item_list = urlList(sb.toString());

			
			System.out.println("파싱 작업: "+ sb);
			
			AreaDto[] ar = new AreaDto[item_list.size()];

			int i = 0;
			for (Element item : item_list) {

				String address = item.getChildText("adres");
				String category_name1 = item.getChildText("tourSe");
				String data_content = item.getChildText("intrcn");
				String category_name2 = item.getChildText("areaSe");
				String telno = item.getChildText("mobileTelno");
				String title = item.getChildText("tourNm");
				String roominfo = item.getChildText("roomInfo");
				String img = item.getChildText("thumbImg");

				AreaDto dto = new AreaDto(address, category_name1, data_content, category_name2, telno, title, roominfo,
						img);

				System.out.println("Saerchdto:"+dto);
				System.out.println();
				System.out.println();
				
				
				ar[i++] = dto;
			}

			model.addAttribute("list", ar);
			model.addAttribute("start", startNum);
			model.addAttribute("end", endNum - 1);
		}
		
		
		
		

//  넘기는 건 잘 되는데 어떻게 뿌려야 할지를 모름		
//		URL url = null;
//		
//		int i = 1;
//		while(i<11) {
//		if("경상".equals(String.valueOf(request.getParameter("des"))) || "경상남".equals(String.valueOf(request.getParameter("des")))||
//				"경남".equals(String.valueOf(request.getParameter("des"))) || "경상남도".equals(String.valueOf(request.getParameter("des")))){
//			url = new URL("http://apis.data.go.kr/6480000/gyeongnamlodgeinfo/gyeongnamlodgeinfolist?ServiceKey=LymnrNWuKh%2Fy7EZcYycf4cfSzKDriE38ICY5nsnLuPZbphsaOHGDaWAO%2F%2B45yD1EkQkH79tD6C%2FLjMCHXAfk0A%3D%3D&pageNo="+i+"&numOfRows=10&resultType=json");
//		}
//		else if("충청".equals(String.valueOf(request.getParameter("des"))) || "충청북".equals(String.valueOf(request.getParameter("des")))||
//				"충북".equals(String.valueOf(request.getParameter("des"))) || "충청북도".equals(String.valueOf(request.getParameter("des")))) {
//			url = new URL("https://api.odcloud.kr/api/15053066/v1/uddi:eb0c728a-7fe7-4a22-80c3-eb4df0825bbd_201911061419?page="+i+"&perPage=10&returnType=json&serviceKey=LymnrNWuKh%2Fy7EZcYycf4cfSzKDriE38ICY5nsnLuPZbphsaOHGDaWAO%2F%2B45yD1EkQkH79tD6C%2FLjMCHXAfk0A%3D%3D");
//		}
//        
//			
//		
//		HttpURLConnection conn = (HttpURLConnection) url.openConnection();
//        conn.setRequestMethod("GET");
//        conn.setRequestProperty("Content-type", "application/json");
//        System.out.println("Response code: " + conn.getResponseCode());
//        BufferedReader rd;
//        if(conn.getResponseCode() >= 200 && conn.getResponseCode() <= 300) {
//            rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
//        } else {
//            rd = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
//        }
//        StringBuilder sb = new StringBuilder();
//        String line;
//        while ((line = rd.readLine()) != null) {
//            sb.append(line);
//        }
//        
//        
//        JSONObject jsonObject = new JSONObject(); 
//        
//        rd.close();
//        conn.disconnect();
//        System.out.println(sb.toString());
//		model.addAttribute("res"+i,sb.toString());
//		
//		i++;
//		}

		
		
		return "searchPage";

	}

	private List<Element> urlList(String sb) throws Exception {

		URL url = new URL(sb);
		HttpURLConnection conn = (HttpURLConnection) url.openConnection();

		conn.setRequestProperty("Content-Type", "application/xml");

		conn.connect();

		SAXBuilder builder = new SAXBuilder();

		Document document = builder.build(conn.getInputStream());

		Element root = document.getRootElement();
		Element body = root.getChild("body");
		Element items = body.getChild("items");
		List<Element> item_list = items.getChildren("item");

		return item_list;
	}
}