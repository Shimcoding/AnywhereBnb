package com.telco.bnb.service;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Service;

import com.telco.bnb.dto.AreaDto;
import com.telco.bnb.dto.UserDto;

public interface AreaService {
	
	//DB area에 지역 정보 넣기
	public void area_register(AreaDto dto) throws Exception;
	
	//DB area에 모든 정보 삭제
	public void area_delete() throws Exception;
	
	//DB area에 레코드가 남아 있는지 확인
	public int area_select(AreaDto dto) throws Exception;
	
}
