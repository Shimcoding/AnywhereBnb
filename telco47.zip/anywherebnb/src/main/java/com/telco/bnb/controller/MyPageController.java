package com.telco.bnb.controller;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.telco.bnb.dto.UserDto;
import com.telco.bnb.service.UserServiceImple;

@Controller
public class MyPageController {

	@Autowired
    private UserServiceImple userServiceImple;
	
	//비밀번호 암호화
	@Autowired(required = false)
	BCryptPasswordEncoder pwdEncoder;
	
	//마이페이지로 가기 전 비밀번호 확인 페이지로 이동
	@RequestMapping("/mypagebefore")
	public String mypageBefore1(HttpSession session, HttpServletRequest request,Model model) throws IOException {
		
		//세션에 getid가 없으면 메인화면으로 돌아감.
		
		if(session.getAttribute("dto")==null) {
			
			String msg = URLEncoder.encode("잘못된 접근입니다.","utf-8");
			
			
			return "redirect:/index?msg="+msg;
		}
		
		return "mypageFormbefore";
	}
	
	//폼에서 입력한 비밀번호와 로그인한 비밀번호가 같으면 마이페이지로 이동
	//같이 않으면 현재 페이지 유지
	@RequestMapping("/mypageOk")
	public String mypageBefore2(HttpServletRequest request,HttpSession session) throws IOException {
		
		UserDto dto = (UserDto)session.getAttribute("dto");
		
		System.out.println("dtopwd:"+dto.getPwd());
		System.out.println(request.getParameter("pwd"));
		
		boolean isMatches = pwdEncoder.matches(request.getParameter("pwd"), dto.getPwd());
		
		if(isMatches) {
			return "mypageForm";
		} else {
			String msg = URLEncoder.encode("비밀번호를 다시 입력해주세요.","utf-8");
			return "redirect:/mypagebefore?msg="+msg;
		}
		
	}
	
	//비밀번호 확인 후 마이페이지로 이동
//	@RequestMapping("/mypage")
//	public String mypage(HttpSession session, Model model) {
//		model.addAttribute("mydto", session.);
//		
//		System.out.println(dto);
//		
//		return "mypageFormbefore";
//	}
}
