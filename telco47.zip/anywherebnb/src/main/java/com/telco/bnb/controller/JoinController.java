package com.telco.bnb.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class JoinController {
	
	//메인 화면으로
	@RequestMapping("/index")
	public String main() {
		return "index";
	}
	
}