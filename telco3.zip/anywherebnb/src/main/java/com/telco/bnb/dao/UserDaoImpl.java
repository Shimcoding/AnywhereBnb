package com.telco.bnb.dao;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.telco.bnb.dto.UserDto;
import com.telco.bnb.mapper.UserMapper;

@Repository
public class UserDaoImpl implements UserDao{

	public UserDaoImpl() {
		
	}
	
	@Autowired(required = false) //Inject 쓰지 말고 Autowired으로 고치기
	private SqlSession sqlSession;

	
	//회원가입
	@Override
	public void register(UserDto dto) throws Exception {
//		System.out.println("userDao: "+ dto);
		System.out.println("회원가입 DB 접근 시작");
//		sqlSession.insert(namespace+".register", dto);
		
		try {
			sqlSession.insert("com.telco.bnb.mapper.UserMapper.register", dto);
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("이유: " + e.getMessage());
			System.out.println("이유: " + e.getLocalizedMessage());
		}
		
		System.out.println("회원가입 DB 접근 종료");
	}


	//로그인
	@Override
	public UserDto getUser(UserDto dto) {
		
		System.out.println("로그인 DB 접근 시작");
		
		return sqlSession.selectOne("com.telco.bnb.mapper.UserMapper.getUser",dto);
	}


	//비밀번호 확인
	@Override
	public UserDto getPwd(UserDto dto) throws Exception {
		System.out.println("비밀번호 확인 DB 접근 시작");
		
		return sqlSession.selectOne("com.telco.bnb.mapper.UserMapper.getPwd", dto.getPwd());
	}


	//아이디 찾기
	@Override
	public UserDto findId(UserDto dto) throws Exception {
		
		return sqlSession.selectOne("com.telco.bnb.mapper.UserMapper.findId", dto);
	}


	//비밀번호 찾기
	@Override
	public UserDto findPwd(UserDto dto) throws Exception {

		return sqlSession.selectOne("com.telco.bnb.mapper.UserMapper.findPwd", dto);
	}
	
	

}
