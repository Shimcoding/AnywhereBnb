package com.telco.bnb.mapper;

import com.telco.bnb.dto.UserDto;

public interface UserMapper {
	
	//회원가입
	public void register(UserDto dto) throws Exception;
	
	//로그인
	public UserDto getUser(UserDto dto) throws Exception;
	
	//비밀번호 확인
	public UserDto getPwd(UserDto dto) throws Exception;
	
	//아이디 찾기
	public UserDto findId(UserDto dto) throws Exception;
	
	//비밀번호 찾기
	public UserDto findPwd(UserDto dto) throws Exception;
}
