package com.telco.bnb.controller;


import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.telco.bnb.dto.UserDto;
import com.telco.bnb.mapper.UserMapper;
import com.telco.bnb.service.UserService;

@Controller // 
@RequestMapping("/register")
public class RegisterController {

	@Autowired(required = true)
	private UserService userService;
	
	@Autowired(required = false)
	private UserMapper userMapper;
	


	//회원가입 화면으로
	@GetMapping("/add") // 4.3부터 추가
	public String register(HttpSession session) throws Exception {
		if(session.getAttribute("dto")!=null) {
			String msg = URLEncoder.encode("잘못된 접근입니다.","utf-8");
			
			return "redirect:/index?msg="+msg;
		}
		return "registerForm"; // WEB-INF/views/registerForm.jsp
	}

	//회원가입이 완료하면 메인 화면으로
	@PostMapping("/add")
	public String save(UserDto dto) throws Exception {
//		System.out.println("controller:" + dto);
		
		try {
			userService.register(dto);
//			userMapper.register(dto);
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("회원가입 성공");

		return "redirect:/index";
	}

}
