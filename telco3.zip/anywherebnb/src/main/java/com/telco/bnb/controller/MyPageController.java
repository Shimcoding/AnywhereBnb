package com.telco.bnb.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.telco.bnb.dto.UserDto;
import com.telco.bnb.service.UserServiceImple;

@Controller
public class MyPageController {

	@Autowired
    private UserServiceImple userServiceImple;
	
	//마이페이지로 가기 전 비밀번호 확인 페이지로 이동
	@RequestMapping("/mypagebefore")
	public String mypageBefore1(HttpSession session, Model model) {
		
		return "mypageFormbefore";
	}
	
	//폼에서 입력한 비밀번호와 로그인한 비밀번호가 같으면 마이페이지로 이동
	//같이 않으면 현재 페이지 유지
	@RequestMapping("/mypageOk")
	public String mypageBefore2(UserDto dto,HttpServletRequest request) {
		
		try {
			UserDto userDto = userServiceImple.getPwd(dto);
			System.out.println(userDto);
			
			return userDto.getPwd().equals(request.getAttribute("cur_pwd")) ? "forward:/mypage" : "forward:/mypagebefore";
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}
	
	//비밀번호 확인 후 마이페이지로 이동
	@RequestMapping("/mypage")
	public String mypage(UserDto dto, Model model) {
		model.addAttribute("mydto", dto);
		
		return "mypageFormbefore";
	}
}
