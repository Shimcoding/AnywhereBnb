package com.telco.bnb.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.telco.bnb.dto.UserDto;
import com.telco.bnb.service.UserServiceImple;

@Controller
@RequestMapping("/find")
public class FindController {

	@Autowired
    private UserServiceImple userServiceImple;
	
	//아이디 찾기 폼으로 이동
	@RequestMapping("/userid")
	public String findId1() {
		
		return "findidForm";
	}
	
	//찾을 정보 입력해서 정보가 틀리면 check가 1을 맞으면 check가 0과 userDto에 해당 아이디와 다른 정보를 넣는다. 
	@PostMapping("/useridOk")
	public String findId2(UserDto dto, Model model) throws Exception {
		System.out.println("아이디 찾기 시작");
		
		UserDto userDto = userServiceImple.findId(dto);
		
		if(userDto == null) {
			model.addAttribute("check", 1);
		} else {
			model.addAttribute("check", 0);
			model.addAttribute("userDto", userDto.getId());
		}
		
		System.out.println(userDto);
		
		return "findidCheck";
	}
	
	//비밀번호 찾기 폼으로 이동
	@RequestMapping("/userpwd")
	public String findPwd1() {
		
		return "findpwdForm";
	}
	
	//찾을 정보 입력해서 정보가 틀리면 check가 1을 맞으면 check가 0과 userDto에 해당 아이디와 다른 정보를 넣는다. 
	@PostMapping("/userpwdOk")
	public String findPwd2(UserDto dto, Model model) throws Exception {
		System.out.println("비밀번호 찾기 시작");
		
		UserDto userDto = userServiceImple.findId(dto);
		
		if(userDto == null) {
			model.addAttribute("check", 1);
		} else {
			model.addAttribute("check", 0);
		}
		
		System.out.println(userDto);
		
		return "updatepwdForm";
	}
	
}
