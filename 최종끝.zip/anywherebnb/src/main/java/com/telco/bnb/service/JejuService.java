package com.telco.bnb.service;

import java.util.List;

import com.telco.bnb.dto.JejuDto;

public interface JejuService {
	
	// 숙박 테이블 타이틀, 주소로 검색 count 값
	public int sukCountSearch(JejuDto dto) throws Exception;
	
	// 숙박 테이블 타이틀, 주소로 검색 값
	public List<JejuDto> sukSearch(JejuDto dto) throws Exception;
	
//	// 음식점 테이블 타이틀, 주소로 검색 count 값
//	public int resCountSearch(JejuDto dto) throws Exception;
//	
//	// 음식점 테이블 타이틀, 주소로 검색 값
//	public JejuDto resSearch(JejuDto dto) throws Exception;
//	
//	// 스팟 테이블 타이틀, 주소로 검색 count 값
//	public int spotCountSearch(JejuDto dto) throws Exception;
//	
//	// 스팟 테이블 타이틀, 주소로 검색 값
//	public JejuDto spotSearch(JejuDto dto) throws Exception;
}
