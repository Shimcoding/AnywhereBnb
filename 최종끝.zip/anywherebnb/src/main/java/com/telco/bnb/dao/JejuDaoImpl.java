package com.telco.bnb.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.telco.bnb.dto.JejuDto;

@Repository
public class JejuDaoImpl implements JejuDao {

	@Autowired(required = false) //Inject 쓰지 말고 Autowired으로 고치기
	private SqlSession sqlSession;
	
	//숙박 카운트
	@Override
	public int sukCountSearch(JejuDto dto) throws Exception{
		return sqlSession.selectOne("com.telco.bnb.mapper.JejuMapper.sukCountSearch", dto);
	}

	//숙박 검색값
	@Override
	public List<JejuDto> sukSearch(JejuDto dto) throws Exception {
		return sqlSession.selectList("com.telco.bnb.mapper.JejuMapper.sukSearch", dto);
	}

//	//음식점 카운트
//	@Override
//	public int resCountSearch(JejuDto dto) throws Exception {
//		return sqlSession.selectOne("com.telco.bnb.mapper.JejuMapper.resCountSearch", dto.getAddress());
//	}
//
//	//음식점 검색값
//	@Override
//	public JejuDto resSearch(JejuDto dto) throws Exception {
//		return sqlSession.selectOne("com.telco.bnb.mapper.JejuMapper.resSearch", dto.getAddress());
//	}
//
//	//스팟 카운트
//	@Override
//	public int spotCountSearch(JejuDto dto) throws Exception {
//		return sqlSession.selectOne("com.telco.bnb.mapper.JejuMapper.spotCountSearch", dto.getAddress());
//	}
//
//	//스팟 검색값
//	@Override
//	public JejuDto spotSearch(JejuDto dto) throws Exception {
//		return sqlSession.selectOne("com.telco.bnb.mapper.JejuMapper.spotSearch", dto.getAddress());
//	}

}
