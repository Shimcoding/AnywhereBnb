package com.telco.bnb.dto;

public class JejuDto {

	private String title;
	private String address;
	private String telno;
	
	public JejuDto() {
		// TODO Auto-generated constructor stub
	}
	
	public JejuDto(String title, String address) {
		this(title,address," ");
	}

	public JejuDto(String title, String address, String telno) {
		super();
		this.title = title;
		this.address = address;
		this.telno = telno;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getTelno() {
		return telno;
	}

	public void setTelno(String telno) {
		this.telno = telno;
	}

	@Override
	public String toString() {
		return "JejuDto [title=" + title + ", address=" + address + ", telno=" + telno + "]";
	}
	
	
	
}
