package com.telco.bnb.controller;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class PageController {

	//처음 페이지
	@GetMapping("/firstpaging")
	public String pagingFirst(Model model,HttpServletRequest request) throws Exception {
		
		//페이징 초깃값 설정
		int preStart = 0;
		int preEnd = 19;
		String startDate = request.getParameter("startDate").trim();
		String endDate = request.getParameter("endDate").trim();

		
		model.addAttribute("des", request.getParameter("des").trim());
		model.addAttribute("start", String.valueOf(preStart).trim());
		model.addAttribute("end", String.valueOf(preEnd).trim());
		model.addAttribute("startDate", startDate);
		model.addAttribute("endDate", endDate);
		model.addAttribute("startCur", request.getParameter("startCur"));
		model.addAttribute("startYear", request.getParameter("startYear"));
		model.addAttribute("arr", request.getParameter("arr"));
		model.addAttribute("arr_price", request.getParameter("arr_price"));
		model.addAttribute("payDto", request.getParameter("payDto"));
		model.addAttribute("item_title",request.getParameter("item_title"));
		model.addAttribute("item_price",request.getParameter("item_price"));
		model.addAttribute("su",request.getParameter("su")); //인원 수
		model.addAttribute("startDate_ymd",request.getParameter("startDate_ymd")); //체크인 날짜 년-월-일
		model.addAttribute("endDate_ymd",request.getParameter("endDate_ymd")); //체크아웃 날짜 년-월-일
		
		
		String area_name = URLEncoder.encode(String.valueOf(request.getParameter("des")).trim() ,"utf-8");
		
		
		return "redirect:/search?des="+area_name.trim()+"&start="+String.valueOf(preStart).trim()
				+"&end="+String.valueOf(preEnd).trim()+"&startDate="+startDate+"&endDate="+endDate;
	}
	
	//이전 페이지
	@GetMapping("/prepaging")
	public String pagingPre(Model model,HttpServletRequest request) throws Exception {
		
		
		int preStart = Integer.valueOf(request.getParameter("start").trim())-20;
		int preEnd = Integer.valueOf(request.getParameter("end").trim())-20;
		String startDate = request.getParameter("startDate").trim();
		String endDate = request.getParameter("endDate").trim();
		
		if(preStart < 19)
			preStart = 0;
		if(preEnd < 19)
			preEnd = 19;
		
		model.addAttribute("des", request.getParameter("des"));
		model.addAttribute("start", String.valueOf(preStart));
		model.addAttribute("end", String.valueOf(preEnd));
		model.addAttribute("startDate", startDate);
		model.addAttribute("endDate", endDate);
		model.addAttribute("startCur", request.getParameter("startCur"));
		model.addAttribute("startYear", request.getParameter("startYear"));
		model.addAttribute("arr", request.getParameter("arr"));
		model.addAttribute("arr_price", request.getParameter("arr_price"));
		model.addAttribute("payDto", request.getParameter("payDto"));
		model.addAttribute("item_title",request.getParameter("item_title"));
		model.addAttribute("item_price",request.getParameter("item_price"));
		model.addAttribute("su",request.getParameter("su")); //인원 수
		model.addAttribute("startDate_ymd",request.getParameter("startDate_ymd")); //체크인 날짜 년-월-일
		model.addAttribute("endDate_ymd",request.getParameter("endDate_ymd")); //체크아웃 날짜 년-월-일
		
		String area_name = URLEncoder.encode(String.valueOf(request.getParameter("des")).trim() ,"utf-8");
		
		
		return "redirect:/search?des="+area_name+"&start="+String.valueOf(preStart)
				+"&end="+String.valueOf(preEnd)+"&startDate="+startDate+"&endDate="+endDate;
	}
	
	//다음 페이지
	@GetMapping("/nextpaging")
	public String pagingNext(Model model,HttpServletRequest request) throws Exception {
		
		
		int nextStart = Integer.valueOf(request.getParameter("start").trim())+19;
		int nextEnd = Integer.valueOf(request.getParameter("end").trim())+19;
		int cnt = Integer.valueOf(request.getParameter("cnt").trim())-19;
		String startDate = request.getParameter("startDate").trim();
		String endDate = request.getParameter("endDate").trim();
		
		model.addAttribute("des", request.getParameter("des").trim());
		model.addAttribute("cnt", cnt);
		model.addAttribute("start", String.valueOf(nextStart));
		model.addAttribute("end", String.valueOf(nextEnd));
		model.addAttribute("startDate", startDate);
		model.addAttribute("endDate", endDate);
		model.addAttribute("startCur", request.getParameter("startCur"));
		model.addAttribute("startYear", request.getParameter("startYear"));
		model.addAttribute("arr", request.getParameter("arr"));
		model.addAttribute("arr_price", request.getParameter("arr_price"));
		model.addAttribute("payDto", request.getParameter("payDto"));
		model.addAttribute("item_title",request.getParameter("item_title"));
		model.addAttribute("item_price",request.getParameter("item_price"));
		model.addAttribute("su",request.getParameter("su")); //인원 수
		model.addAttribute("startDate_ymd",request.getParameter("startDate_ymd")); //체크인 날짜 년-월-일
		model.addAttribute("endDate_ymd",request.getParameter("endDate_ymd")); //체크아웃 날짜 년-월-일
		
		String area_name = URLEncoder.encode(String.valueOf(request.getParameter("des")).trim() ,"utf-8");
		
		
		return "redirect:/search?des="+area_name.trim()+"&start="+String.valueOf(nextStart)
				+"&end="+String.valueOf(nextEnd)+"&cnt="+String.valueOf(cnt)+"&startDate="+startDate+"&endDate="+endDate;
		
	}

	
	//끝 페이지
	@GetMapping("/endpaging")
	public String pagingEnd(Model model,HttpServletRequest request) throws Exception {
		
		
		int nextStart = Integer.valueOf(request.getParameter("cnt").trim())-19;
		int nextEnd = Integer.valueOf(request.getParameter("cnt").trim());
		String startDate = request.getParameter("startDate").trim();
		String endDate = request.getParameter("endDate").trim();
		
		model.addAttribute("cnt", request.getParameter("cnt").trim());
		model.addAttribute("start", String.valueOf(nextStart));
		model.addAttribute("end", String.valueOf(nextEnd));
		model.addAttribute("startDate", startDate);
		model.addAttribute("endDate", endDate);
		model.addAttribute("startCur", request.getParameter("startCur"));
		model.addAttribute("startYear", request.getParameter("startYear"));
		model.addAttribute("arr", request.getParameter("arr"));
		model.addAttribute("arr_price", request.getParameter("arr_price"));
		model.addAttribute("payDto", request.getParameter("payDto"));
		model.addAttribute("item_title",request.getParameter("item_title"));
		model.addAttribute("item_price",request.getParameter("item_price"));
		model.addAttribute("su",request.getParameter("su")); //인원 수
		model.addAttribute("startDate_ymd",request.getParameter("startDate_ymd")); //체크인 날짜 년-월-일
		model.addAttribute("endDate_ymd",request.getParameter("endDate_ymd")); //체크아웃 날짜 년-월-일
		
		String des = URLEncoder.encode(String.valueOf(request.getParameter("des")).trim() ,"utf-8");
		
		
		return "redirect:/search?des="+des+"&start="+String.valueOf(nextStart).trim()
				+"&end="+String.valueOf(nextEnd).trim()+"&startDate="+startDate+"&endDate="+endDate;
	}
}
