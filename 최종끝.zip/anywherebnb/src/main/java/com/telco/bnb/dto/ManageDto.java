package com.telco.bnb.dto;

public class ManageDto {
	
	private String buyer_name;
	private String buyer_email;
	private String buyer_tel;
	private String title;
	private String address;
	private String price;
	private String su;
	private String date;
	
	public ManageDto() {
		// TODO Auto-generated constructor stub
	}
	
	public ManageDto(String buyer_name, String buyer_email, String buyer_tel, String title, String address,
			String price, String su, String date) {
		super();
		this.buyer_name = buyer_name;
		this.buyer_email = buyer_email;
		this.buyer_tel = buyer_tel;
		this.title = title;
		this.address = address;
		this.price = price;
		this.su = su;
		this.date = date;
	}

	public String getBuyer_name() {
		return buyer_name;
	}

	public void setBuyer_name(String buyer_name) {
		this.buyer_name = buyer_name;
	}

	public String getBuyer_email() {
		return buyer_email;
	}

	public void setBuyer_email(String buyer_email) {
		this.buyer_email = buyer_email;
	}

	public String getBuyer_tel() {
		return buyer_tel;
	}

	public void setBuyer_tel(String buyer_tel) {
		this.buyer_tel = buyer_tel;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public String getSu() {
		return su;
	}

	public void setSu(String su) {
		this.su = su;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	@Override
	public String toString() {
		return "ManageDto [buyer_name=" + buyer_name + ", buyer_email=" + buyer_email + ", buyer_tel=" + buyer_tel
				+ ", title=" + title + ", address=" + address + ", price=" + price + ", su=" + su + ", date=" + date
				+ "]";
	}
	
	
	
	
	
}
