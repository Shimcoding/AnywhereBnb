package com.telco.bnb.controller;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.request;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;


@Controller
public class JoinController {
	
	//메인 화면으로 이동
	@GetMapping("/index")
	public String index(Model model, HttpSession session, HttpServletRequest request) {
		
		
		LocalDate now = LocalDate.now();
		
		//년-월-일 현재 날짜 1년 뒤 날짜
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		
		//월-일 현재 날짜 1년 뒤 날짜
		DateTimeFormatter formatter1 = DateTimeFormatter.ofPattern("MM-dd");
		DateTimeFormatter formatter2 = DateTimeFormatter.ofPattern("yyyy");
		
		String start11 = formatter.format(now);
		String last11 = formatter.format(now.plusYears(1));
		String startCur = formatter1.format(now);
		String startYear = formatter2.format(now);
		String endCur = formatter1.format(now.plusDays(1));
		
		model.addAttribute("start11",start11);
		model.addAttribute("last11",last11);
		model.addAttribute("startCur",startCur);
		model.addAttribute("endCur",endCur);
		model.addAttribute("startYear",startYear);
		model.addAttribute("msg",request.getParameter("msg"));
		
		
		
		return "index";
	}
	
	
	//도움말로 이동
	@GetMapping("/help")
	public String help() {
		return "helpForm";
	}
	
	
	
}