package com.telco.bnb.controller;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class PageController {

	@GetMapping("/firstpaging")
	public String paging0(Model model,HttpServletRequest request) throws Exception {
		
		
		int preStart = 0;
		int preEnd = 5;
		
		model.addAttribute("list", request.getParameter("list"));
		model.addAttribute("area_num", request.getParameter("area_num"));
		model.addAttribute("start", String.valueOf(preStart));
		model.addAttribute("end", String.valueOf(preEnd));
		
		String area_name = URLEncoder.encode(request.getParameter("area_name"),"utf-8");
		
		return "redirect:/search?des="+area_name+"&start="+String.valueOf(preStart)
				+"&end="+String.valueOf(preEnd);
	}
	
	@GetMapping("/prepaging")
	public String paging1(Model model,HttpServletRequest request) throws Exception {
		
		
		int preStart = Integer.valueOf(request.getParameter("start").trim())-5;
		int preEnd = Integer.valueOf(request.getParameter("end").trim())-4;
		
		model.addAttribute("list", request.getParameter("list"));
		model.addAttribute("area_num", request.getParameter("area_num"));
		model.addAttribute("start", String.valueOf(preStart));
		model.addAttribute("end", String.valueOf(preEnd));
		
		String area_name = URLEncoder.encode(request.getParameter("area_name"),"utf-8");
		
		return "redirect:/search?des="+area_name+"&start="+String.valueOf(preStart)
				+"&end="+String.valueOf(preEnd);
	}
	
	@GetMapping("/nextpaging")
	public String paging2(Model model,HttpServletRequest request) throws Exception {
		
		
		int nextStart = Integer.valueOf(request.getParameter("start").trim())+5;
		int nextEnd = Integer.valueOf(request.getParameter("end").trim())+6;
		int lastNum = Integer.valueOf(request.getParameter("area_num").trim())-5;
		
		model.addAttribute("list", request.getParameter("list"));
		model.addAttribute("area_num", request.getParameter("area_num"));
		model.addAttribute("area_num2", lastNum);
		model.addAttribute("start", String.valueOf(nextStart));
		model.addAttribute("end", String.valueOf(nextEnd));
		
		
		String area_name = URLEncoder.encode(request.getParameter("area_name"),"utf-8");
		
		return "redirect:/search?des="+area_name+"&start="+String.valueOf(nextStart)
				+"&end="+String.valueOf(nextEnd)+"&lastEnd="+String.valueOf(lastNum);
		
	}

	@GetMapping("/endpaging")
	public String paging3(Model model,HttpServletRequest request) throws Exception {
		
		
		System.out.println("endpagine: "+request.getParameter("area_num").trim());
		int nextStart = Integer.valueOf(request.getParameter("area_num").trim())-5;
		int nextEnd = Integer.valueOf(request.getParameter("area_num").trim());
		System.out.println(nextStart);
		System.out.println(nextEnd);
		
		model.addAttribute("list", request.getParameter("list"));
		model.addAttribute("area_num", request.getParameter("area_num"));
		model.addAttribute("start", String.valueOf(nextStart));
		model.addAttribute("end", String.valueOf(nextEnd));
		
		
		String area_name = URLEncoder.encode(request.getParameter("area_name"),"utf-8");
		
		return "redirect:/search?des="+area_name+"&start="+String.valueOf(nextStart)
				+"&end="+String.valueOf(nextEnd);
	}
}
