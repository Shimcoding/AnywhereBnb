package com.telco.bnb.controller;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.request;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;


@Controller
public class JoinController {
	
	private static final Logger logger = LoggerFactory.getLogger(JoinController.class);
	
	//메인 화면으로 이동
	@GetMapping("/index")
	public ModelAndView index(Model model, HttpSession session, HttpServletRequest request) {
		
		//오늘 날짜 계산
		LocalDate now = LocalDate.now();
		
		//년-월-일 현재 날짜 1년 뒤 날짜
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		
		//월-일 현재 날짜 1년 뒤 날짜
		DateTimeFormatter formatter1 = DateTimeFormatter.ofPattern("MM-dd");
		DateTimeFormatter formatter2 = DateTimeFormatter.ofPattern("yyyy");
		
		ModelAndView mv = new ModelAndView();
		mv.addObject("start11",formatter.format(now));
		mv.addObject("last11",formatter.format(now.plusYears(1)));
		mv.addObject("startCur",formatter1.format(now));
		mv.addObject("startYear",formatter2.format(now));
		mv.addObject("endCur",formatter1.format(now.plusDays(1)));
		mv.addObject("msg",request.getParameter("msg"));
		mv.setViewName("index");
		
		
		
		return mv;
	}
	
	//도움말로 이동
	@GetMapping("/help")
	public String help() {
		return "helpForm";
	}
	
	
	
}