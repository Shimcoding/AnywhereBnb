
package com.telco.bnb.controller;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.telco.bnb.dto.UserDto;
import com.telco.bnb.service.UserService;
import com.telco.bnb.service.UserServiceImple;

@Controller
public class UpdateController {
	
	@Autowired
    private UserService userService;
	
	//비밀번호 암호화
	@Autowired
	private BCryptPasswordEncoder pwdEncoder;
	
	//비밀번호 변경
	@PostMapping("/updatePwd")
	public String updatePwd(HttpServletRequest request) {
		
		
		try {
			HttpSession session = request.getSession();
			
			//비밀번호 암호화
			String inputPass = request.getParameter("newPwd1");
			String pwd = pwdEncoder.encode(inputPass);
			
			userService.updatePw(request.getParameter("userId"), pwd);
			session.invalidate();
			
			//변경에 성공하면 로그인 화면으로
			return "redirect:/login/login";
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		String msg = "";
		try {
			 msg = URLEncoder.encode("변경에 실패하였습니다.", "utf-8");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		
		//변경에 실패하면 
		return "redirect:/index?msg="+msg;
	}
	
	
	
}
