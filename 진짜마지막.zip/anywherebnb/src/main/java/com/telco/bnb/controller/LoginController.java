package com.telco.bnb.controller;

import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.log;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.telco.bnb.dto.UserDto;
import com.telco.bnb.service.UserService;
import com.telco.bnb.service.UserServiceImple;


@Controller
@RequestMapping("/login")
public class LoginController {
	
	private static final Logger logger = LoggerFactory.getLogger(LoginController.class);
	
	@Autowired
    private UserService userService;
	
	@Autowired
	private BCryptPasswordEncoder passwordEncoder;
	
	
	//로그인 입력 화면으로
	@GetMapping("/login")
    public String login(HttpSession session){
		
		//로그인이 된 상태이면 경고창 발생과 함께 초기 화면으로 이동
        return session.getAttribute("dto")!=null ? "redirect:/index?msg="+loginError() : "loginForm";
    
	}



	 //로그인 성공,실패 여부
    @PostMapping("/login")
    public String loginCheck(HttpServletRequest request, UserDto dto, boolean rememberId,
    		RedirectAttributes rttr, HttpServletResponse response, String pwd){
    	
    	
    	//사용자가 입력한 비밀번호와 암호화된 비밀번호와 비교
    	//복호화해서 같으면 1반환, 다르면 0반환 
    	UserDto encode = null;
		try {
			encode = userService.getIdPwd(dto);
		} catch (Exception e) {
			e.printStackTrace();
		}
    	
    	//세션 객체 생성(객체에 null 값 대신 다른 값이 들어가 있으면 로그인 상태인데 로그인하러 들어 온 거)
		HttpSession session = request.getSession();
		
		
    	//아이디가 잘못돼 로그인을 실패할 경우
    	if(encode == null) {
    		
    		return "redirect:/login/login?msg="+encodeIdFail(encode, session);
    	}
    	
    	boolean isMatches = passwordEncoder.matches(pwd, encode.getPwd());
    	
		dto.setPwd(encode.getPwd());
		UserDto userDto = null;
		try {
			userDto = userService.getUser(dto);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
		//아이디는 맞았는데 비밀번호가 틀린 경우,아이디와 비밀번호 모두 맞아서 로그인이 된 경우
		//isMatches가 false면 틀린 경우, true이면 로그인이 된 경우
		if(!isMatches) {
			
			return "redirect:/login/login?msg=" + matchCheck(isMatches,session,rttr);
			
		} else {
			
			//아이디와 비밀번호 모두 맞아서 로그인이 된 경우
			session.setAttribute("dto", userDto);
			
			//아이디 기억 버튼이 눌러 있으면
			isReminder(rememberId, response, userDto);
			
			System.out.println("로그인 성공");
			
			//로그인 성공 시 로그인체크 1로 변경
			
			return "redirect:/index";
			
			
		}
			
    	
    }


    //아이디 기억 버튼 클릭 시 다음 로그인 때 아이디 기억
	private void isReminder(boolean rememberId, HttpServletResponse response, UserDto userDto) {
		if(rememberId) {
			
			//쿠키 생성
			Cookie cookie = new Cookie("id", userDto.getId());
			cookie.setMaxAge(60);
			
			//응답에 저장
			response.addCookie(cookie);
		} else {
			
			//아이디 기억 버튼이 눌러 있지 않다면
			
			//쿠키 삭제
			Cookie cookie = new Cookie("id", userDto.getId());
			cookie.setMaxAge(0);
			
			//응답에 저장
			response.addCookie(cookie);
		}
	}

    
    
    
    //잘못된 방법으로 로그인 시도를 할 경우 경고 메시지 출력 후 초기 화면으로 이동
    private String loginError() {
		String msg = "";
		try {
			msg = URLEncoder.encode("잘못된 접근입니다.","utf-8");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return msg;
	}
    
    
    //로그인 시 비밀번호가 틀린 경우
    private String matchCheck(boolean isMatches, HttpSession session, RedirectAttributes rttr) {
    	
    	//isMatches == false
		session.setAttribute("dto", null);
		rttr.addFlashAttribute("msg", false);
		
		//아이디 또는 비밀번호가 틀렸을 때
		String msg = loginFail();
		
		//메시지 넘겨 주기
		return msg;
	}



	//로그아웃 실행
    @GetMapping("/logout")
    public String logout(HttpSession session) throws Exception {
    //UserDto dto1 = (UserDto)session.getAttribute("dto");
        
        
    	// 1. 세션을 종료
        session.removeAttribute("dto");
        //session.invalidate();  
       
        //로그아웃이 되었다는 경고창 출력
        String msg = URLEncoder.encode("성공적으로 로그아웃이 되었습니다.","utf-8");
        
        // 2. 홈으로 이동
        return "redirect:/index?msg="+msg;
    }
    
    
    
    
    
    
    //아이디가 잘못돼 로그인에 실패할 때 사용 메서드
    private String encodeIdFail(UserDto encode, HttpSession session) {
		session.setAttribute("dto", null);
		
		//아이디 또는 비밀번호가 틀렸을 때
		String msg = loginFail();
		
		return msg;
    }
    
    
    //로그인이 실패되었을 때 메시지 출력하는 메서드
	private String loginFail() {
		String msg = "";
		
		try {
			msg = URLEncoder.encode("아이디 또는 비밀번호가 틀렸습니다.","utf-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return msg;
	}
	

}
