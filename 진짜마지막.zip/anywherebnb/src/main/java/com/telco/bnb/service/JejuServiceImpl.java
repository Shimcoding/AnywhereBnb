package com.telco.bnb.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.telco.bnb.dao.JejuDao;
import com.telco.bnb.dto.JejuDto;

@Service
public class JejuServiceImpl implements JejuService {

	@Autowired(required = false)
	private JejuDao dao;
	
	@Override
	public int sukCountSearch(JejuDto dto) throws Exception  {
		return dao.sukCountSearch(dto);
	}

	@Override
	public List<JejuDto> sukSearch(JejuDto dto) throws Exception {
		return dao.sukSearch(dto);
	}


}
