package com.telco.bnb.dto;

public class PayDto {

	private String buyer_email;
	private String buyer_name;
	private String buyer_tel;
	
	public PayDto() {
	}
	
	public PayDto(String buyer_email, String buyer_name, String buyer_tel) {
		super();
		this.buyer_email = buyer_email;
		this.buyer_name = buyer_name;
		this.buyer_tel = buyer_tel;
	}


	public String getBuyer_email() {
		return buyer_email;
	}

	public void setBuyer_email(String buyer_email) {
		this.buyer_email = buyer_email;
	}

	public String getBuyer_name() {
		return buyer_name;
	}

	public void setBuyer_name(String buyer_name) {
		this.buyer_name = buyer_name;
	}

	public String getBuyer_tel() {
		return buyer_tel;
	}

	public void setBuyer_tel(String buyer_tel) {
		this.buyer_tel = buyer_tel;
	}

	@Override
	public String toString() {
		return "PayDto [buyer_email=" + buyer_email
				+ ", buyer_name=" + buyer_name + ", buyer_tel=" + buyer_tel + "]";
	}
	
	
	
	
}
