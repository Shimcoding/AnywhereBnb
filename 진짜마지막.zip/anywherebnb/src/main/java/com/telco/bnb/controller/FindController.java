package com.telco.bnb.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.telco.bnb.dto.UserDto;
import com.telco.bnb.service.UserService;
import com.telco.bnb.service.UserServiceImple;

import lombok.extern.slf4j.Slf4j;


@Controller
@RequestMapping("/find")
public class FindController {

	private final Logger logger = LoggerFactory.getLogger(FindController.class);
	
	public void log() {
		logger.trace("Trace");
		logger.info("Info");
		logger.error("Error");
	}
	
	@Autowired
    private UserService userService;
	
	
	//아이디 찾기 폼으로 이동
	@GetMapping("/userid")
	public String findId() {
		log();
		return "findidForm";
	}
	
	
	//찾을 정보 입력해서 정보가 틀리면 check가 1을 맞으면 check가 0과 userDto에 해당 아이디와 다른 정보를 넣는다. 
	@PostMapping("/userid")
	public String findIdOk(UserDto dto, Model model) throws Exception {
		log();
		//중복된 코드 분리
		userFindIdPwd(dto, model);
		
		return "findidCheck";
	}
	
	
	//비밀번호 찾기 폼으로 이동
	@GetMapping("/userpwd")
	public String findPwd() {
		log();
		return "findpwdForm";
	}
	
	
	
	//찾을 정보 입력해서 정보가 틀리면 check가 1을 맞으면 check가 0과 userDto에 해당 아이디와 다른 정보를 넣는다. 
	@PostMapping("/userpwd")
	public String findPwdOk(UserDto dto, Model model) throws Exception {
		
		//중복된 코드 분리
		userFindIdPwd(dto, model);
		
		
		return "updatepwdForm";
	}

	
	//아이디, 비밀번호 찾기 한 메서드로 묶기
	private void userFindIdPwd(UserDto dto,Model model) {
		
		UserDto userDto = null;
		try {
			userDto = userService.findId(dto);
		} catch (Exception e) {
			logger.warn("e.getMessage() : {}, userDto : {}",e.getMessage(), userDto);
		}
		
		if(userDto == null) {
			model.addAttribute("check", 1);
		} else {
			model.addAttribute("check", 0);
			model.addAttribute("userDto", userDto.getId());
		}
		
	}
	
	
	
}
