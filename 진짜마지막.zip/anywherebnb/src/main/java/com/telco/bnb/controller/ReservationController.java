package com.telco.bnb.controller;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.telco.bnb.dto.ManageDto;
import com.telco.bnb.dto.PayDto;
import com.telco.bnb.dto.UserDto;
import com.telco.bnb.service.ManageService;
import com.telco.bnb.service.UserService;
import com.telco.bnb.service.UserServiceImple;




@Controller
public class ReservationController {

	@Autowired
	private ManageService manageService;
	
	@Autowired
    private UserService userService;
	
	
	//비밀번호 암호화
	@Autowired
	private BCryptPasswordEncoder pwdEncoder;
	
	
	//예약 후 결제 페이지로 이동
	@PostMapping("/reservation")
	public String reservation_in(HttpSession session, Model model,PayDto payDto,HttpServletRequest request) {
		
		
		model.addAttribute("payDto",payDto);
		model.addAttribute("item_title",request.getParameter("item_title"));
		model.addAttribute("item_price",request.getParameter("item_price"));
		model.addAttribute("address",request.getParameter("address"));
		model.addAttribute("su",request.getParameter("su"));
		model.addAttribute("num",request.getParameter("num"));
		model.addAttribute("startDate_ymd",request.getParameter("startDate_ymd"));
		model.addAttribute("endDate_ymd",request.getParameter("endDate_ymd"));
		model.addAttribute("buyer_email",request.getParameter("buyer_email"));
		model.addAttribute("buyer_name",request.getParameter("buyer_name"));
		model.addAttribute("buyer_tel",request.getParameter("buyer_tel"));
		
		
		return session.getAttribute("dto") == null ?  "redirect:/index?msg="+loginError() : "payForm";
	}
	
	
	//예약 관리로 들어가기 전 비밀번호 확인
	@GetMapping("/managebefore")
	public String managebefore(HttpSession session, HttpServletRequest request) {

		return session.getAttribute("dto")==null ? "redirect:/index?msg="+loginError() : "manageFormbefore";
	}
	
	
	//해당 사용자의 예약 정보 가져오기
	@PostMapping("/manageOk")
	public String mypageOk(HttpSession session, HttpServletRequest request, Model model) {
		
		
		UserDto dto = (UserDto)session.getAttribute("dto");
		boolean isMatches = pwdEncoder.matches(request.getParameter("pwd"), dto.getPwd());
		
		if(isMatches) {
			
			try {
				//사용자의 예약 정보 확인해서 예약 정보를 보여 준다.
				reservationCheck(request, model, dto);
			} catch (Exception e) {
				e.printStackTrace();
			}
			
			return session.getAttribute("dto")==null ? "redirect:/index?msg="+loginError() : "manageForm";
			
		} else {
			
			String msg1 = "";
			try {
				msg1 = URLEncoder.encode("비밀번호를 다시 입력해주세요.","utf-8");
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return "redirect:/mypagebefore?msg="+msg1;
		
		}
		
	}


	
	
	//예약 관리에 정보 넣고 메인 화면으로 이동
	@PostMapping("/manage")	
	public @ResponseBody String manage(@RequestParam Map<String, Object> map) throws Exception {
		manageService.manage(map);
		
		return "index";
	}
	
	//예약 취소
	@PostMapping("/manageDelete")
	@ResponseBody
	public void manageDelete(HttpServletRequest request){
		String[] valueArr = request.getParameterValues("valueArr");
		
		ManageDto mdto = new ManageDto();
		valueArrSet(valueArr, mdto);
		
		
	}

	
	
	

	//예약 취소한 항목들을 for문으로 돌려 
	private void valueArrSet(String[] valueArr, ManageDto mdto) {
		for (int i = 0; i < valueArr.length; i++) {
			
			try {
				mdto.setTitle(valueArr[i].substring(0,valueArr[i].indexOf(",")));
				mdto.setDate(valueArr[i].substring(valueArr[i].indexOf(",")+1));
				manageService.deleteRes(mdto);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	
	
	//로그인이 안 된 상태에서 예약 정보를 확인할 경우
	private String loginError() {
		String msg = "";
		try {
			msg = URLEncoder.encode("잘못된 접근입니다.","utf-8");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return msg;
	}
	
	
	//사용자의 예약 정보를 가져오는 메서드
	private void reservationCheck(HttpServletRequest request, Model model, UserDto dto) throws Exception {
		UserDto myDto = userService.mypage(dto);
		myDto.setPwd(request.getParameter("pwd"));
		model.addAttribute("myDto", myDto);


		UserDto uDto = userService.mypage(dto);
		
		ManageDto resDto = new ManageDto();
		resDto.setBuyer_name(uDto.getName());
		resDto.setBuyer_email(uDto.getEmail());
		resDto.setBuyer_tel(uDto.getTel());
		
		List<ManageDto> list = manageService.findRes(resDto);
		
		
		model.addAttribute("list",list);
		model.addAttribute("size", list.size() == 0 ? 0 : list.size());
	}
	
}
