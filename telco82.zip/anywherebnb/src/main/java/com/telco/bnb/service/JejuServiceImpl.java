package com.telco.bnb.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.telco.bnb.dao.JejuDao;
import com.telco.bnb.dto.JejuDto;

@Service
public class JejuServiceImpl implements JejuService {

	@Autowired(required = false)
	private JejuDao dao;
	
	@Override
	public int sukCountSearch(JejuDto dto) throws Exception  {
		System.out.println("숙소 검색 카운트 시작");
		return dao.sukCountSearch(dto);
	}

	@Override
	public List<JejuDto> sukSearch(JejuDto dto) throws Exception {
		System.out.println("숙소 검색 값 시작");
		return dao.sukSearch(dto);
	}

	@Override
	public int resCountSearch(JejuDto dto) throws Exception {
		System.out.println("음식점 검색 카운트 시작");
		return dao.resCountSearch(dto);
	}

	@Override
	public JejuDto resSearch(JejuDto dto) throws Exception {
		System.out.println("음식점 검색값 시작");
		return dao.resSearch(dto);
	}

	@Override
	public int spotCountSearch(JejuDto dto) throws Exception {
		System.out.println("스팟 검색 카운트 시작");
		return dao.spotCountSearch(dto);
	}

	@Override
	public JejuDto spotSearch(JejuDto dto) throws Exception {
		System.out.println("스팟 검색값 시작");
		return dao.spotSearch(dto);
	}

}
