package com.telco.bnb.controller;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.ibatis.reflection.SystemMetaObject;
import org.codehaus.jackson.map.ObjectMapper;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.input.SAXBuilder;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.sun.mail.imap.protocol.Item;
import com.telco.bnb.dto.AreaDto;
import com.telco.bnb.dto.JejuDto;
import com.telco.bnb.paging.Criteria;
import com.telco.bnb.service.AreaServiceImple;
import com.telco.bnb.service.JejuService;
import com.telco.bnb.service.JejuServiceImpl;
import com.telco.bnb.service.UserServiceImple;

import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.io.BufferedReader;
import java.io.IOException;


@Controller
public class SearchController {

	@Autowired
	private JejuServiceImpl jejuServiceImpl;
	
	@GetMapping("/search")
	public String search(HttpServletRequest request, Model model, JejuDto jdto) throws IOException, Exception {
		HttpSession session = request.getSession();

		if (session.getAttribute("dto") == null) {
			return "redirect:/login/login";
		}

		try {
			int checkin = Integer.valueOf(request.getParameter("startDate").replaceAll("-", "")).intValue();
			int checkout = Integer.valueOf(request.getParameter("endDate").replaceAll("-", "")).intValue();

			if (checkin >= checkout) {
				String msg = URLEncoder.encode("체크인 날짜가 체크아웃 날짜보다 크거가 같을 수 업습니다.", "utf-8");

				return "redirect:/index?msg=" + msg;
			}
		} catch (NullPointerException e) {
			System.out.println("처음에서 확인 완료");
		}
		// 체크인 날짜가 체크아웃 날짜보다 크거나 같으면 다시 메인 화면으로

		int start = request.getParameter("start") == null ? 0 : Integer.valueOf(request.getParameter("start"));
		int end = request.getParameter("end") == null ? 4 : Integer.valueOf(request.getParameter("end"));
		
		jdto.setAddress(request.getParameter("des"));
		jdto.setTitle(request.getParameter("des"));
		System.out.println("jdto:"+jdto);
		
		// 검색 결과 개수
		int cnt = jejuServiceImpl.sukCountSearch(jdto);
		// 검색된 데이터의 이름,주소,전화번호(전화번호는 없을 수 있음)
		List<JejuDto> list = jejuServiceImpl.sukSearch(jdto);
		

		LocalDate now = LocalDate.now();
		
		
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

		String start11 = formatter.format(now);
		String last11 = formatter.format(now.plusYears(1));
		
		model.addAttribute("start11",start11);
		model.addAttribute("last11",last11);
		
		model.addAttribute("cnt",cnt);
		model.addAttribute("list",list);
		model.addAttribute("des",request.getParameter("des"));
		model.addAttribute("start",start);
		model.addAttribute("end",end);
		
		int arr = (int)((Math.random()*9)+1)*10000;
		model.addAttribute("arr",arr);
		
		return "searchPage";

	}

}