package com.telco.bnb.controller;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class PageController {

	@GetMapping("/firstpaging")
	public String paging0(Model model,HttpServletRequest request) throws Exception {
		
		
		int preStart = 0;
		int preEnd = 4;
		String startDate = request.getParameter("startDate").trim();
		String endDate = request.getParameter("endDate").trim();

		
		model.addAttribute("des", request.getParameter("des").trim());
		model.addAttribute("start", String.valueOf(preStart).trim());
		model.addAttribute("end", String.valueOf(preEnd).trim());
		model.addAttribute("startDate", startDate);
		model.addAttribute("endDate", endDate);
		
		String area_name = URLEncoder.encode(String.valueOf(request.getParameter("des")).trim() ,"utf-8");
		
		
		return "redirect:/search?des="+area_name.trim()+"&start="+String.valueOf(preStart).trim()
				+"&end="+String.valueOf(preEnd).trim()+"&startDate="+startDate+"&endDate="+endDate;
	}
	
	@GetMapping("/prepaging")
	public String paging1(Model model,HttpServletRequest request) throws Exception {
		
		
		int preStart = Integer.valueOf(request.getParameter("start").trim())-5;
		int preEnd = Integer.valueOf(request.getParameter("end").trim())-5;
		String startDate = request.getParameter("startDate").trim();
		String endDate = request.getParameter("endDate").trim();
		
		if(preStart < 4)
			preStart = 0;
		if(preEnd < 4)
			preEnd = 4;
		
		model.addAttribute("des", request.getParameter("des"));
		model.addAttribute("start", String.valueOf(preStart));
		model.addAttribute("end", String.valueOf(preEnd));
		model.addAttribute("startDate", startDate);
		model.addAttribute("endDate", endDate);
		
		String area_name = URLEncoder.encode(String.valueOf(request.getParameter("des")).trim() ,"utf-8");
		
		
		return "redirect:/search?des="+area_name+"&start="+String.valueOf(preStart)
				+"&end="+String.valueOf(preEnd)+"&startDate="+startDate+"&endDate="+endDate;
	}
	
	@GetMapping("/nextpaging")
	public String paging2(Model model,HttpServletRequest request) throws Exception {
		
		
		int nextStart = Integer.valueOf(request.getParameter("start").trim())+5;
		int nextEnd = Integer.valueOf(request.getParameter("end").trim())+5;
		int cnt = Integer.valueOf(request.getParameter("cnt").trim())-5;
		String startDate = request.getParameter("startDate").trim();
		String endDate = request.getParameter("endDate").trim();
		
		model.addAttribute("des", request.getParameter("des").trim());
		model.addAttribute("cnt", cnt);
		model.addAttribute("start", String.valueOf(nextStart));
		model.addAttribute("end", String.valueOf(nextEnd));
		model.addAttribute("startDate", startDate);
		model.addAttribute("endDate", endDate);
		
		
		String area_name = URLEncoder.encode(String.valueOf(request.getParameter("des")).trim() ,"utf-8");
		
		
		return "redirect:/search?des="+area_name.trim()+"&start="+String.valueOf(nextStart)
				+"&end="+String.valueOf(nextEnd)+"&cnt="+String.valueOf(cnt)+"&startDate="+startDate+"&endDate="+endDate;
		
	}

	@GetMapping("/endpaging")
	public String paging3(Model model,HttpServletRequest request) throws Exception {
		
		
		int nextStart = Integer.valueOf(request.getParameter("cnt").trim())-4;
		int nextEnd = Integer.valueOf(request.getParameter("cnt").trim());
		String startDate = request.getParameter("startDate").trim();
		String endDate = request.getParameter("endDate").trim();
		
		model.addAttribute("cnt", request.getParameter("cnt").trim());
		model.addAttribute("start", String.valueOf(nextStart));
		model.addAttribute("end", String.valueOf(nextEnd));
		model.addAttribute("startDate", startDate);
		model.addAttribute("endDate", endDate);
		
		
		String des = URLEncoder.encode(String.valueOf(request.getParameter("des")).trim() ,"utf-8");
		
		
		return "redirect:/search?des="+des+"&start="+String.valueOf(nextStart).trim()
				+"&end="+String.valueOf(nextEnd).trim()+"&startDate="+startDate+"&endDate="+endDate;
	}
}
