package com.telco.bnb.controller;


import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.type.TypeReference;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.telco.bnb.dto.UserDto;
import com.telco.bnb.mapper.UserMapper;
import com.telco.bnb.service.UserService;

@Controller // 
@RequestMapping("/register")
public class RegisterController {

	@Autowired(required = true)
	private UserService userService;
	
	@Autowired(required = false)
	private UserMapper userMapper;
	
	//비밀번호 암호화
	@Autowired(required = false)
	BCryptPasswordEncoder pwdEncoder;
	

	//회원가입 화면으로
	@GetMapping("/add") // 4.3부터 추가
	public String register(HttpSession session) throws Exception {
		if(session.getAttribute("dto")!=null) {
			String msg = URLEncoder.encode("잘못된 접근입니다.","utf-8");
			
			return "redirect:/index?msg="+msg;
		}
		return "registerForm"; // WEB-INF/views/registerForm.jsp
	}

	//회원가입이 완료하면 메인 화면으로
	@PostMapping("/add")
	public String save(UserDto dto) throws Exception {
//		System.out.println("controller:" + dto);
		
		int result = userService.idChk(dto);
		
		try {
			if(result == 1) {
				System.out.println("중복된 아이디");
				return "redirect:/register/add";
			} else if(result == 0){
				//비밀번호 암호화
				String inputPass = dto.getPwd();
				String pwd = pwdEncoder.encode(inputPass);
				dto.setPwd(pwd);
				
				userService.register(dto);
				System.out.println(dto);
			}
			
//			userMapper.register(dto);
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("회원가입 성공");

		return "redirect:/index";
	}
	
	//아이디 중복체크
	@ResponseBody
	@PostMapping(value = "/idChk")
	public int idChk(UserDto dto) throws Exception{
		
		return userService.idChk(dto);
		
	}
	
	//이메일 중복체크
	@ResponseBody
	@PostMapping(value = "/emailChk")
	public int emailChk(UserDto dto) throws Exception{
		
		return userService.emailChk(dto);
		
	}
	
	//연락처 중복체크
	@ResponseBody
	@PostMapping(value = "/telChk")
	public int telChk(UserDto dto) throws Exception{
		
		return userService.telChk(dto);
		
	}
	
	

}
