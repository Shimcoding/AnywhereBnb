package com.telco.bnb.controller;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.telco.bnb.dto.UserDto;
import com.telco.bnb.service.UserServiceImple;

@Controller
public class MyPageController {

	@Autowired
    private UserServiceImple userServiceImple;
	
	//비밀번호 암호화
	@Autowired(required = false)
	BCryptPasswordEncoder pwdEncoder;
	
	//마이페이지로 가기 전 비밀번호 확인 페이지로 이동
	@RequestMapping("/mypagebefore")
	public String mypageBefore1(HttpSession session, HttpServletRequest request,Model model) throws IOException {
		
		//로그인이 안 된 상태이면 다시 메인 화면으로 이동
		if(session.getAttribute("dto")==null) {
			
			String msg = URLEncoder.encode("잘못된 접근입니다.","utf-8");
			
			
			return "redirect:/index?msg="+msg;
		}
		
		return "mypageFormbefore";
	}
	
	//폼에서 입력한 비밀번호와 로그인한 비밀번호가 같으면 마이페이지로 이동
	//같이 않으면 현재 페이지 유지
	@PostMapping("/mypageOk")
	public String mypageBefore2(HttpServletRequest request, Model model) throws Exception {
		HttpSession session = request.getSession();
		
		if(session.getAttribute("dto")==null) {
			
			String msg = URLEncoder.encode("잘못된 접근입니다.","utf-8");
			
			
			return "redirect:/index?msg="+msg;
		}
		
		UserDto dto = (UserDto)session.getAttribute("dto");
		System.out.println("비밀번호 확인:"+dto.getPwd());
		System.out.println(request.getParameter("pwd"));
		
		System.out.println("dto전체:"+dto);
		
		boolean isMatches = pwdEncoder.matches(request.getParameter("pwd"), dto.getPwd());
		
		if(isMatches) {
			
			UserDto myDto = userServiceImple.mypage(dto);
			myDto.setPwd(request.getParameter("pwd"));
			model.addAttribute("myDto", myDto);
			
			return "mypageForm";
			
		} else {
			
			String msg = URLEncoder.encode("비밀번호를 다시 입력해주세요.","utf-8");
			return "redirect:/mypagebefore?msg="+msg;
		
		}
		
	}
	
	
	//회원탈퇴
	@PostMapping("/mypageDelete")
	public String mypageDelete(HttpServletRequest request) throws Exception {
		
		HttpSession session = request.getSession();
		
		//로그인이 안 된 상태이면 다시 메인 화면으로 이동
		if(session.getAttribute("dto")==null) {
			
			String msg = URLEncoder.encode("잘못된 접근입니다.","utf-8");
			
			
			return "redirect:/index?msg="+msg;
		}
		
		UserDto dto = (UserDto)session.getAttribute("dto");
		userServiceImple.mypageDelete(dto.getId());
		try {
			session.removeAttribute("dto");
		} catch (Exception e) {
			System.out.println("그래도 잘 삭제 됨");
		}
		
		
		
		
		
		return "redirect:/index";
		
	}
	
	
	//회원 정보 변경
	@PostMapping("/mypageUpdate")
	public String mypageUpdate(HttpSession session, UserDto dto1, String newPwd1) throws Exception {
		
		//로그인이 안 된 상태이면 다시 메인 화면으로 이동
		if(session.getAttribute("dto")==null) {
			
			String msg = URLEncoder.encode("잘못된 접근입니다.","utf-8");
			
			
			return "redirect:/index?msg="+msg;
		}
		
		
		UserDto dto = (UserDto)session.getAttribute("dto");
		UserDto UpdateDto = dto1;
		UpdateDto.setId(dto.getId());
		
		
		
		boolean isMatches = pwdEncoder.matches(newPwd1, dto.getPwd());
		
		if(isMatches) {
			//수정한 비밀번호가 이전과 같다면
			UpdateDto.setPwd(dto.getPwd());
			
		} else {
			
			//수정한 비밀번호가 이전과 다르다면
			String pwd = pwdEncoder.encode(newPwd1);
			UpdateDto.setPwd(pwd);
			
		}
		
		userServiceImple.mypageUpdate(UpdateDto);
		
		session.removeAttribute("dto");
		
		return "redirect:/index";
	}
	
}
