package com.telco.dao;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.telco.dto.UserDto;

@Service
public class UserDaoImpl implements UserDao{

	@Autowired(required = false) //Autowired
	private SqlSession sqlSession;

	private static String namespace = "userMapper";
	
	@Override
	public void register(UserDto dto) throws Exception {
		sqlSession.insert(namespace+".register", dto);
	}

}
