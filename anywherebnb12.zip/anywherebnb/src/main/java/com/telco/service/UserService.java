package com.telco.service;

import org.springframework.stereotype.Service;

import com.telco.dto.UserDto;

public interface UserService {
	void register(UserDto dto) throws Exception;
}
