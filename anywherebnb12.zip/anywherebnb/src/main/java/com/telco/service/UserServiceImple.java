package com.telco.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.telco.dao.UserDao;
import com.telco.dto.UserDto;

@Service
public class UserServiceImple implements UserService{

	@Autowired(required = false)
	private UserDao dao;
	

	@Override
	public void register(UserDto dto) throws Exception {
		System.out.println("1");
		dao.register(dto);
		
	}
	
}
