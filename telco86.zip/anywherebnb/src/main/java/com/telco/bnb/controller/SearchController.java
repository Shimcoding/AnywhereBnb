package com.telco.bnb.controller;

import java.io.IOException;
import java.net.URLEncoder;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.telco.bnb.dto.JejuDto;
import com.telco.bnb.service.JejuServiceImpl;


@Controller
public class SearchController {

	@Autowired
	private JejuServiceImpl jejuServiceImpl;
	
	@GetMapping("/search")
	public String search(HttpServletRequest request, Model model, JejuDto jdto) throws IOException, Exception {
		HttpSession session = request.getSession();

		if (session.getAttribute("dto") == null) {
			return "redirect:/login/login";
		}

		int checkin = Integer.valueOf(request.getParameter("startDate").replaceAll("-", "")).intValue();
		int checkout = Integer.valueOf(request.getParameter("endDate").replaceAll("-", "")).intValue();

		if (checkin >= checkout) {
			String msg = URLEncoder.encode("체크인 날짜가 체크아웃 날짜보다 크거가 같을 수 업습니다.", "utf-8");

			return "redirect:/index?msg=" + msg;
		}
		// 체크인 날짜가 체크아웃 날짜보다 크거나 같으면 다시 메인 화면으로

		int start = request.getParameter("start") == null ? 0 : Integer.valueOf(request.getParameter("start"));
		int end = request.getParameter("end") == null ? 4 : Integer.valueOf(request.getParameter("end"));
		
		jdto.setAddress(request.getParameter("des"));
		jdto.setTitle(request.getParameter("des"));
		System.out.println("jdto:"+jdto);
		
		// 검색 결과 개수
		int cnt = jejuServiceImpl.sukCountSearch(jdto);
		// 검색된 데이터의 이름,주소,전화번호(전화번호는 없을 수 있음)
		List<JejuDto> list = jejuServiceImpl.sukSearch(jdto);
		
		
		//현재 날짜 구하기
		LocalDate now = LocalDate.now();
		
		
		//현재 날짜 이전과 현재 날짜로부터 1년이 넘는 날짜들은 선택 불가
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

		String start11 = formatter.format(now);
		String last11 = formatter.format(now.plusYears(1));
		
		model.addAttribute("start11",start11); //현재 날짜
		model.addAttribute("last11",last11); //현재로부터 1년 뒤 날짜
		
		
		
		model.addAttribute("cnt",cnt); //검색을 통해 나온 객체들의 총 수
		model.addAttribute("list",list); //검색을 통해 나온 객체들
		model.addAttribute("des",request.getParameter("des")); //검색어
		model.addAttribute("start",start); //페이징
		model.addAttribute("end",end); //페이징 
		model.addAttribute("su",request.getParameter("su")); //인원 수
		
		
		//체크인 날짜와 체크아웃 날짜 사이의 간격 계산 -> 몇 박 동안 숙박하는지
		Date format1 = new SimpleDateFormat("yyyy-MM-dd").parse(request.getParameter("startDate"));
		Date format2 = new SimpleDateFormat("yyyy-MM-dd").parse(request.getParameter("endDate"));
		
		long diff = ((format2.getTime() - format1.getTime()) / 1000) / (24*60*60);
		
		model.addAttribute("startDate",request.getParameter("startDate"));
		model.addAttribute("endDate",request.getParameter("endDate"));
		model.addAttribute("diff",diff); //숙박일
		
		
		
		//임의로 책정한 가격
		int arr = (int)((Math.random()*9)+1)*10000;
		model.addAttribute("arr",arr); //임의로 책정한 가격
		
		return "searchPage";

	}

}