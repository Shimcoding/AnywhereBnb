package com.telco.bnb.controller;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.request;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;


@Controller
public class JoinController {
	
	//메인 화면으로
	@RequestMapping("/index")
	public String main(Model model, HttpSession session, HttpServletRequest request) {
		
		
		LocalDate now = LocalDate.now();
		
		System.out.println("현재날짜:"+now);
		
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

		String start11 = formatter.format(now);
		String last11 = formatter.format(now.plusYears(1));
		
		model.addAttribute("start11",start11);
		model.addAttribute("last11",last11);
		model.addAttribute("msg",request.getParameter("msg"));
		
		
		
		
		return "index";
	}
	
	//도움말로
	@GetMapping("/help")
	public String help() {
		return "helpForm";
	}
	
	//결제 페이지로
	@GetMapping("/pay")
	public String pay() {
		
		System.out.println("잘 들어옴");
		
		return "payForm";
	}
	
	
	
}