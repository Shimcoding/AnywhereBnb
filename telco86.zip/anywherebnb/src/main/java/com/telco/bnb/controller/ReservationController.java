package com.telco.bnb.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.telco.bnb.dto.AreaDto;
import com.telco.bnb.dto.UserDto;

@Controller
public class ReservationController {

	@GetMapping("/reservation")
	public String reservation(Model model,HttpServletRequest request) {
		System.out.println("잘 들어왔나");

		
		System.out.println("list:"+request.getParameter("list"));
		System.out.println("start:"+request.getParameter("start"));
		System.out.println("end:"+request.getParameter("end"));
		System.out.println("price:"+request.getParameter("price"));
		System.out.println("su:"+request.getParameter("su"));
		
		return "test";
	}
	
	@RequestMapping("/complete")
	public String com() {
		
		return "test1";
	}
	
	@RequestMapping("/fail")
	public String fail() {
		
		return "test2";
	}
	
}
