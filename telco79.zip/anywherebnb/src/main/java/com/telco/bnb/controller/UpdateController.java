package com.telco.bnb.controller;

import java.net.URLEncoder;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.telco.bnb.dto.UserDto;
import com.telco.bnb.service.UserServiceImple;

@Controller
public class UpdateController {
	
	@Autowired
    private UserServiceImple userServiceImple;
	
	//비밀번호 암호화
	@Autowired(required = false)
	BCryptPasswordEncoder pwdEncoder;
	
	//비밀번호 변경
	@PostMapping("/updatePwd")
	public String updatePwd(HttpServletRequest request) {
		
		
		try {
			HttpSession session = request.getSession();
			
			//비밀번호 암호화
			String inputPass = request.getParameter("newPwd1");
			String pwd = pwdEncoder.encode(inputPass);
			
			userServiceImple.updatePw(request.getParameter("userId"), pwd);
			session.invalidate();
			
			//변경에 성공하면 로그인 화면으로
			return "redirect:/login/login";
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		//변경에 실패하면 
		return null;
	}
	
	
	
}
