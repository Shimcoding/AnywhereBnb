package com.telco.bnb.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.telco.bnb.dao.ManageDao;
import com.telco.bnb.dto.ManageDto;
import com.telco.bnb.dto.UserDto;

@Service
public class ManageServiceImpl implements ManageService {

	@Autowired
	private ManageDao dao;
	
	@Override
	public void manage(Map<String, Object> param) throws Exception {
		System.out.println("예약 정보 서비스 시작");
		dao.manage(param);
	}

	@Override
	public List<ManageDto> findRes(ManageDto dto) throws Exception {
		System.out.println("예약 정보 확인 서비스 시작");
		System.out.println("예약:"+dto);
		return dao.findRes(dto);
	}

}
