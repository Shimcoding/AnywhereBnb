package com.telco.bnb.dao;

import java.util.List;
import java.util.Map;

import com.telco.bnb.dto.ManageDto;
import com.telco.bnb.dto.PayDto;
import com.telco.bnb.dto.UserDto;


public interface ManageDao {
	
	//예약 정보 삽입
	public void manage(Map<String, Object> param) throws Exception;
	
	//현재 사용자의 예약 관리 정보 가져오기
	public List<ManageDto> findRes(ManageDto dto) throws Exception;
}
