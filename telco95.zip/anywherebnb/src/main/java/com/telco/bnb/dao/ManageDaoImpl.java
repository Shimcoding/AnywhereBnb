package com.telco.bnb.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.telco.bnb.dto.ManageDto;
import com.telco.bnb.dto.PayDto;
import com.telco.bnb.dto.UserDto;

@Repository
public class ManageDaoImpl implements ManageDao {

	@Autowired(required = false) //Inject 쓰지 말고 Autowired으로 고치기
	private SqlSession sqlSession;
	
	@Override
	public void manage(Map<String, Object> map) throws Exception {
		System.out.println("예약 정보 dao DB 접근 시작");
		sqlSession.insert("com.telco.bnb.mapper.ManageMapper.manage", map);
	}

	@Override
	public List<ManageDto> findRes(ManageDto dto) throws Exception {
		System.out.println("예약 정보 아이디,이메일,연락처로 접근 시작");
		System.out.println("예약 정보 dto: "+ dto);
		return sqlSession.selectList("com.telco.bnb.mapper.ManageMapper.findRes", dto);
	}


}
