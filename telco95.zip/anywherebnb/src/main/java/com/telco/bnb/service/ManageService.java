package com.telco.bnb.service;

import java.util.List;
import java.util.Map;

import com.telco.bnb.dto.ManageDto;
import com.telco.bnb.dto.PayDto;
import com.telco.bnb.dto.UserDto;


public interface ManageService {
	public void manage(Map<String, Object> map) throws Exception;
	
	//예약 정보 회원 찾기
	public List<ManageDto> findRes(ManageDto dto) throws Exception;
}
