package com.telco.bnb.controller;

import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class Sample {
	public static void main(String[] args) throws IOException, ParseException{ 

		JSONParser parser = new JSONParser();
		// JSON 파일 읽기
		Reader reader = new FileReader("src\\main\\webapp\\resources\\json\\Chunbuk.json");
		Object obj = parser.parse(reader);
		
		JSONObject jsonMain = (JSONObject)obj;
		
		JSONArray jsonArr = (JSONArray)jsonMain.get("result");
		
		
		if(jsonArr.size()>0) {
			for (int i = 0; i < jsonArr.size(); i++) {
				
				JSONObject jsonObj = (JSONObject)jsonArr.get(i);
				
				
				String address = (String)jsonObj.get("adres"); 
				String category_name1 = (String)jsonObj.get("tourSe");
				String data_content = (String)jsonObj.get("intrcn");
				String category_name2 = (String)jsonObj.get("areaSe"); 
				String telno = (String)jsonObj.get("mobileTelno");
				String title = (String)jsonObj.get("tourNm");
				String roominfo = (String)jsonObj.get("roomInfo"); 
				String img = (String)jsonObj.get("thumbImg");
				
				
				System.out.println(address); // apple
				System.out.println(category_name1); // 1
				System.out.println(data_content); // 1000
				System.out.println(category_name2); // 1000
				System.out.println(telno); // 1000
				System.out.println(title); // 1000
				System.out.println(roominfo); // 1000
				System.out.println(img); // 1000
				System.out.println();
				System.out.println();
			}
		}
		
		

	}
}
