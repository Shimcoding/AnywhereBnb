package com.telco.bnb.service;

import java.util.List;

import com.telco.bnb.dto.AreaDto;
import com.telco.bnb.paging.Criteria;

public interface AreaService {

	// DB area에 지역 정보 넣기
	public void area_register(AreaDto dto) throws Exception;

	// DB area에 모든 정보 삭제
	public void area_delete() throws Exception;

	// DB area에 레코드가 남아 있는지 확인
	public int area_select(AreaDto dto) throws Exception;

	// 시퀀스 생성
	public void area_seq() throws Exception;

	// 시퀀스 초기화
	public void seq_drop() throws Exception;
	
	//페이징
	public List<AreaDto> listCriteria(Criteria criteria) throws Exception;

}
