package com.telco.service;

import org.springframework.stereotype.Service;

import com.telco.dto.UserDto;

public interface UserService {
	public void register(UserDto userDto) throws Exception;
}
