package com.telco.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.telco.dao.UserDao;
import com.telco.dto.UserDto;
import com.telco.mapper.UserMapper;

@Service
public class UserServiceImple implements UserService{

	public void sam() {
		System.out.println("2");
	
	}
	
	@Autowired(required = false)
	UserDao userDao;
	
	@Autowired
	UserMapper userMapper;
	
	public void sam1() {
		System.out.println("3");
	
	}

	@Override
	public void register(UserDto userDto) throws Exception {
		System.out.println("회원가입 서비스 시작");
//		userDao.register(userDto);
		userMapper.register(userDto);
		System.out.println("회원가입 서비스 끝");
		
	}
	
}
