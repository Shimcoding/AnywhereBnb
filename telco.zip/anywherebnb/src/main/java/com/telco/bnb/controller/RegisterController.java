package com.telco.bnb.controller;


import org.mariadb.jdbc.internal.logging.Logger;
import org.mariadb.jdbc.internal.logging.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.telco.dto.UserDto;
import com.telco.mapper.UserMapper;
import com.telco.service.UserService;

@Controller // ctrl+shift+o 자동 임포트
@RequestMapping("/register")
public class RegisterController {

	private static final Logger logger = LoggerFactory.getLogger(RegisterController.class);
	
	@Autowired(required = false)
	UserService userService;
	
	@Autowired(required = false)
	private UserMapper userMapper;


//	@RequestMapping(value="/register/add", method=RequestMethod.GET) // 신규회원 가입
	@GetMapping("/add") // 4.3부터 추가
	public String register() {
		logger.info("get register");
		
		return "registerForm"; // WEB-INF/views/registerForm.jsp
	}

//	@RequestMapping(value="/register/save", method=RequestMethod.POST) // 신규회원 가입
// 	@PostMapping("/register/save")
	@PostMapping("/add")
	public String save(UserDto userDto) throws Exception {
		System.out.println(userDto.toString());
		
		logger.info("post register");
		
		try {
//			userService.register(userDto);
			userMapper.register(userDto);
		} catch (Exception e) {
			System.out.println(e.getStackTrace());
			System.out.println("userDto: "+ userDto.toString());
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
		
		System.out.println("성공");

		return "redirect:/index";
	}

}
