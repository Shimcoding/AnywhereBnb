package com.telco.dao;

import com.telco.dto.UserDto;

public interface UserDao {
	
	//회원가입
	public void register(UserDto userDto) throws Exception;
}
