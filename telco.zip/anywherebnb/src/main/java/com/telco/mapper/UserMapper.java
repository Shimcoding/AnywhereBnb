package com.telco.mapper;

import org.apache.ibatis.annotations.Select;

import com.telco.dto.UserDto;

public interface UserMapper {
	public UserDto register(UserDto userDto);
}
