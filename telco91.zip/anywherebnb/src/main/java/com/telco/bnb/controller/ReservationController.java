package com.telco.bnb.controller;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.telco.bnb.dto.AreaDto;
import com.telco.bnb.dto.PayDto;
import com.telco.bnb.dto.UserDto;

@Controller
public class ReservationController {

	@GetMapping("/reservation")
	public String reservation_out(Model model,HttpServletRequest request) {
		System.out.println("잘 들어왔나");

		
		System.out.println("item_title:"+request.getParameter("item_title"));
		System.out.println("item_price:"+request.getParameter("item_price"));
		System.out.println("buyer_email:"+request.getParameter("buyer_email"));
		System.out.println("buyer_name:"+request.getParameter("buyer_name"));
		System.out.println("buyer_tel:"+request.getParameter("buyer_tel"));
		
		return "test";
	}
	
	@PostMapping("/reservation")
	public String reservation_in(Model model,PayDto paydto,HttpServletRequest request) throws Exception {
		
		HttpSession session = request.getSession();
		
		if(session.getAttribute("dto")==null) {
			String msg = URLEncoder.encode("잘못된 접근입니다.","utf-8");
			
			return "redirect:/index?msg="+msg;
		}
		
		
		model.addAttribute("payDto",paydto);
		model.addAttribute("item_title",request.getParameter("item_title"));
		model.addAttribute("item_price",request.getParameter("item_price"));
		model.addAttribute("address",request.getParameter("address"));
		model.addAttribute("su",request.getParameter("su"));
		
		
		
		return "payForm";
	}
	
	@RequestMapping("/manage")
	public String manage() {
		
		return "manageForm";
	}
	
	@RequestMapping("/fail")
	public String fail() {
		
		return "test2";
	}
	
}
